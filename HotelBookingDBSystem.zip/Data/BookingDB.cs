﻿using PhumlaKamnandi2024.Business;
using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PhumlaKamnandi2024.Data
{
    internal class BookingDB : PhumlaKamnandiDB
    {
        #region Data Members        
        private const string TableName = "Bookings";
        private const string SqlSelect = "SELECT * FROM Bookings";
        private Collection<Booking> bookings;
        #endregion

        #region Property Method: Collection
        public Collection<Booking> AllBookings
        {
            get { return bookings; }
        }
        #endregion

        #region Constructor
        public BookingDB() : base()
        {
            bookings = new Collection<Booking>();
            FillDataSet(SqlSelect, TableName);
            AddToCollection(TableName);
        }
        #endregion

        #region Utility Methods
        public DataSet GetDataSet()
        {
            return dsMain;
        }

        private void AddToCollection(string table)
        {
            bookings.Clear();
            foreach (DataRow myRow in dsMain.Tables[table].Rows)
            {
                if (myRow.RowState != DataRowState.Deleted)
                {
                    var booking = new Booking
                    {
                        BookingID = myRow["BookingID"].ToString().Trim(),
                        GuestID = myRow["GuestID"].ToString().Trim(),
                        CheckInDate = myRow["CheckInDate"].ToString().Trim(),
                        CheckOutDate = myRow["CheckOutDate"].ToString().Trim(),
                        NumberOfRooms = myRow["NumberOfRooms"].ToString().Trim(),
                        TotalAmount = myRow["TotalAmount"].ToString().Trim(),
                        PaymentStatus = myRow["PaymentStatus"].ToString().Trim()
                    };
                    bookings.Add(booking);
                }
            }
        }

        private void FillRow(DataRow row, Booking booking, PhumlaKamnandiDB.DBOperation operation)
        {
            if (operation == PhumlaKamnandiDB.DBOperation.Add)
            {
                row["BookingID"] = booking.BookingID;
            }
            row["GuestID"] = booking.GuestID;
            row["CheckInDate"] = booking.CheckInDate;
            row["CheckOutDate"] = booking.CheckOutDate;
            row["NumberOfRooms"] = booking.NumberOfRooms;
            row["TotalAmount"] = booking.TotalAmount;
            row["PaymentStatus"] = booking.PaymentStatus;
        }

        private int FindRow(Booking booking)
        {
            for (int i = 0; i < dsMain.Tables[TableName].Rows.Count; i++)
            {
                if (dsMain.Tables[TableName].Rows[i].RowState != DataRowState.Deleted &&
                    booking.BookingID == dsMain.Tables[TableName].Rows[i]["BookingID"].ToString())
                {
                    return i;
                }
            }
            return -1; // Not found
        }
        #endregion

        #region Database Operations CRUD
        public void DataSetChange(Booking booking, PhumlaKamnandiDB.DBOperation operation)
        {
            DataRow row = null;

            switch (operation)
            {
                case PhumlaKamnandiDB.DBOperation.Add:
                    row = dsMain.Tables[TableName].NewRow();
                    FillRow(row, booking, operation);
                    dsMain.Tables[TableName].Rows.Add(row);
                    break;

                case PhumlaKamnandiDB.DBOperation.Edit:
                    int index = FindRow(booking);
                    if (index != -1)
                    {
                        row = dsMain.Tables[TableName].Rows[index];
                        FillRow(row, booking, operation);
                    }
                    break;

                case PhumlaKamnandiDB.DBOperation.Delete:
                    int deleteIndex = FindRow(booking);
                    if (deleteIndex != -1)
                    {
                        dsMain.Tables[TableName].Rows[deleteIndex].Delete();
                    }
                    break;
            }

        }
        #endregion

        #region Database Update Methods
        private void Build_INSERT_Parameters()
        {
            daMain.InsertCommand.Parameters.Clear(); // Clear existing parameters

            daMain.InsertCommand.Parameters.Add(new SqlParameter("@BookingID", SqlDbType.NVarChar, 15, "BookingID"));
            daMain.InsertCommand.Parameters.Add(new SqlParameter("@GuestID", SqlDbType.NVarChar, 15, "GuestID"));
            daMain.InsertCommand.Parameters.Add(new SqlParameter("@CheckInDate", SqlDbType.DateTime, 8, "CheckInDate"));
            daMain.InsertCommand.Parameters.Add(new SqlParameter("@CheckOutDate", SqlDbType.DateTime, 8, "CheckOutDate"));
            daMain.InsertCommand.Parameters.Add(new SqlParameter("@NumberOfRooms", SqlDbType.Int, 4, "NumberOfRooms"));
            daMain.InsertCommand.Parameters.Add(new SqlParameter("@TotalAmount", SqlDbType.Decimal, 18, "TotalAmount"));
            daMain.InsertCommand.Parameters.Add(new SqlParameter("@PaymentStatus", SqlDbType.NVarChar, 20, "PaymentStatus"));
        }

        private void Create_INSERT_Command()
        {
            daMain.InsertCommand = new SqlCommand("INSERT INTO Bookings (BookingID, GuestID, CheckInDate, CheckOutDate, NumberOfRooms, TotalAmount, PaymentStatus) VALUES (@BookingID, @GuestID, @CheckInDate, @CheckOutDate, @NumberOfRooms, @TotalAmount, @PaymentStatus)", cnMain);
            Build_INSERT_Parameters(); // Build parameters after creating command
        }

        public bool InsertDataSource(Booking booking)
        {
            bool success = true; // Initialize success as true

            // Create the INSERT command for the booking
            Create_INSERT_Command(); // Call Create_INSERT_Command

            // Set the parameters of the command with values from the booking object
            daMain.InsertCommand.Parameters["@BookingID"].Value = booking.BookingID;
            daMain.InsertCommand.Parameters["@GuestID"].Value = booking.GuestID;
            daMain.InsertCommand.Parameters["@CheckInDate"].Value = booking.CheckInDate;
            daMain.InsertCommand.Parameters["@CheckOutDate"].Value = booking.CheckOutDate;
            daMain.InsertCommand.Parameters["@NumberOfRooms"].Value = booking.NumberOfRooms;
            daMain.InsertCommand.Parameters["@TotalAmount"].Value = booking.TotalAmount;
            daMain.InsertCommand.Parameters["@PaymentStatus"].Value = booking.PaymentStatus;

            try
            {
                // Update the database with the new booking data
                daMain.Update(dsMain, TableName); // Assuming TableName is defined as "Bookings"
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                success = false; // Set success to false if there is an error
            }

            return success; // Return success value
        }

        private void Build_UPDATE_Parameters()
        {
            daMain.UpdateCommand.Parameters.Clear(); // Clear existing parameters

            daMain.UpdateCommand.Parameters.Add(new SqlParameter("@BookingID", SqlDbType.NVarChar, 15, "BookingID"));
            daMain.UpdateCommand.Parameters.Add(new SqlParameter("@GuestID", SqlDbType.NVarChar, 15, "GuestID"));
            daMain.UpdateCommand.Parameters.Add(new SqlParameter("@CheckInDate", SqlDbType.DateTime, 8, "CheckInDate"));
            daMain.UpdateCommand.Parameters.Add(new SqlParameter("@CheckOutDate", SqlDbType.DateTime, 8, "CheckOutDate"));
            daMain.UpdateCommand.Parameters.Add(new SqlParameter("@NumberOfRooms", SqlDbType.Int, 4, "NumberOfRooms"));
            daMain.UpdateCommand.Parameters.Add(new SqlParameter("@TotalAmount", SqlDbType.Decimal, 18, "TotalAmount"));
            daMain.UpdateCommand.Parameters.Add(new SqlParameter("@PaymentStatus", SqlDbType.NVarChar, 20, "PaymentStatus"));
        }

        private void Create_UPDATE_Command()
        {
            daMain.UpdateCommand = new SqlCommand("UPDATE Bookings SET GuestID = @GuestID, CheckInDate = @CheckInDate, CheckOutDate = @CheckOutDate, NumberOfRooms = @NumberOfRooms, TotalAmount = @TotalAmount, PaymentStatus = @PaymentStatus WHERE BookingID = @BookingID", cnMain);
            Build_UPDATE_Parameters(); // Build parameters after creating command
        }

        public bool UpdateDataSource(Booking booking)
        {
            bool success = true; // Initialize success as true

            // Create the UPDATE command for the booking
            Create_UPDATE_Command(); // Call Create_UPDATE_Command

            // Set the parameters of the command with values from the booking object
            daMain.UpdateCommand.Parameters["@BookingID"].Value = booking.BookingID;
            daMain.UpdateCommand.Parameters["@GuestID"].Value = booking.GuestID;
            daMain.UpdateCommand.Parameters["@CheckInDate"].Value = booking.CheckInDate;
            daMain.UpdateCommand.Parameters["@CheckOutDate"].Value = booking.CheckOutDate;
            daMain.UpdateCommand.Parameters["@NumberOfRooms"].Value = booking.NumberOfRooms;
            daMain.UpdateCommand.Parameters["@TotalAmount"].Value = booking.TotalAmount;
            daMain.UpdateCommand.Parameters["@PaymentStatus"].Value = booking.PaymentStatus;

            try
            {
                // Update the database with the new booking data
                daMain.Update(dsMain, TableName); // Assuming TableName is defined as "Bookings"
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                success = false; // Set success to false if there is an error
            }

            return success; // Return success value
        }
        private void Build_DELETE_Parameters()
        {
            daMain.DeleteCommand.Parameters.Clear(); // Clear existing parameters

            daMain.DeleteCommand.Parameters.Add(new SqlParameter("@BookingID", SqlDbType.NVarChar, 15, "BookingID"));
        }

        private void Create_DELETE_Command()
        {
            daMain.DeleteCommand = new SqlCommand("DELETE FROM Bookings WHERE BookingID = @BookingID", cnMain);
            Build_DELETE_Parameters(); // Build parameters after creating command
        }

        public bool DeleteDataSource(Booking booking)
        {
            bool success = true; // Initialize success as true

            // Create the DELETE command for the booking
            Create_DELETE_Command(); // Call Create_DELETE_Command

            // Set the parameter for the command with the BookingID to be deleted
            daMain.DeleteCommand.Parameters["@BookingID"].Value = booking.BookingID;

            try
            {
                // Update the database by deleting the booking
                daMain.Update(dsMain, TableName); // Assuming TableName is defined as "Bookings"
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                success = false; // Set success to false if there is an error
            }

            return success; // Return success value
        }

        private string GetTableName()
        {
            return "Bookings";

        }

        #endregion
    }
}
