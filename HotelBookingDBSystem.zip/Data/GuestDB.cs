﻿using PhumlaKamnandi2024.Business;
using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PhumlaKamnandi2024.Data
{
    internal class GuestDB : PhumlaKamnandiDB
    {
        #region Data Members        
        private const string TableName = "Guests";
        private const string SqlSelect = "SELECT * FROM Guests";
        private Collection<Guest> guests;
        #endregion

        #region Property Method: Collection
        public Collection<Guest> AllGuests
        {
            get { return guests; }
        }
        #endregion

        #region Constructor
        public GuestDB() : base()
        {
            guests = new Collection<Guest>();
            FillDataSet(SqlSelect, TableName);
            AddToCollection(TableName);
        }
        #endregion

        #region Utility Methods
        public DataSet GetDataSet()
        {
            return dsMain;
        }

        private void AddToCollection(string table)
        {
            guests.Clear();
            foreach (DataRow myRow in dsMain.Tables[table].Rows)
            {
                if (myRow.RowState != DataRowState.Deleted)
                {
                    var guest = new Guest
                    {
                        GuestID = myRow["GuestID"].ToString().Trim(),
                        Name = myRow["Name"].ToString().Trim(),
                        Address = myRow["Address"].ToString().Trim(),
                        ContactNumber = myRow["ContactNumber"].ToString().Trim(),
                        Email = myRow["Email"].ToString().Trim()
                    };
                    guests.Add(guest);
                }
            }
        }

        private void FillRow(DataRow row, Guest guest, PhumlaKamnandiDB.DBOperation operation)
        {
            if (operation == PhumlaKamnandiDB.DBOperation.Add)
            {
                row["GuestID"] = guest.GuestID;
            }
            row["Name"] = guest.Name;
            row["Address"] = guest.Address;
            row["ContactNumber"] = guest.ContactNumber;
            row["Email"] = guest.Email;
        }

        private int FindRow(Guest guest)
        {
            for (int i = 0; i < dsMain.Tables[TableName].Rows.Count; i++)
            {
                if (dsMain.Tables[TableName].Rows[i].RowState != DataRowState.Deleted &&
                    guest.GuestID == dsMain.Tables[TableName].Rows[i]["GuestID"].ToString())
                {
                    return i;
                }
            }
            return -1; // Not found
        }
        #endregion

        #region Database Operations CRUD
        public void DataSetChange(Guest guest, PhumlaKamnandiDB.DBOperation operation)
        {
            DataRow row = null;

            switch (operation)
            {
                case PhumlaKamnandiDB.DBOperation.Add:
                    row = dsMain.Tables[TableName].NewRow();
                    FillRow(row, guest, operation);
                    dsMain.Tables[TableName].Rows.Add(row);
                    break;

                case PhumlaKamnandiDB.DBOperation.Edit:
                    int index = FindRow(guest);
                    if (index != -1)
                    {
                        row = dsMain.Tables[TableName].Rows[index];
                        FillRow(row, guest, operation);
                    }
                    break;

                case PhumlaKamnandiDB.DBOperation.Delete:
                    int deleteIndex = FindRow(guest);
                    if (deleteIndex != -1)
                    {
                        dsMain.Tables[TableName].Rows[deleteIndex].Delete();
                    }
                    break;
            }

        }
        #endregion

        #region Database Update Methods
        private void Build_INSERT_Parameters(Guest guest)
        {
            SqlParameter param = new SqlParameter("@GuestID", SqlDbType.NVarChar, 15, "GuestID");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Name", SqlDbType.NVarChar, 100, "Name");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Address", SqlDbType.NVarChar, 255, "Address");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@ContactNumber", SqlDbType.NVarChar, 15, "ContactNumber");
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Email", SqlDbType.NVarChar, 100, "Email");
            daMain.InsertCommand.Parameters.Add(param);
        }

        private void Create_INSERT_Command(Guest guest)
        {
            daMain.InsertCommand = new SqlCommand("INSERT INTO Guests (GuestID, Name, Address, ContactNumber, Email) VALUES (@GuestID, @Name, @Address, @ContactNumber, @Email)", cnMain);
            Build_INSERT_Parameters(guest);
        }

        public bool UpdateDataSource(Guest guest)
        {
            bool success = true; // Initialize success as true

            // Create the INSERT command for the guest
            Create_INSERT_Command(guest); // Call Create_INSERT_Command

            // Set the parameters of the command with values from the guest object
            daMain.InsertCommand.Parameters["@GuestID"].Value = guest.GuestID;
            daMain.InsertCommand.Parameters["@Name"].Value = guest.Name;
            daMain.InsertCommand.Parameters["@Address"].Value = guest.Address;
            daMain.InsertCommand.Parameters["@ContactNumber"].Value = guest.ContactNumber;
            daMain.InsertCommand.Parameters["@Email"].Value = guest.Email;

            try
            {
                // Update the database with the new guest data
                daMain.Update(dsMain, TableName); // Assuming TableName is defined as "Guests"
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                success = false; // Set success to false if there is an error
            }

            return success; // Return success value
        }
        private string GetTableName()
        {
            return "Guests";

        }
        #endregion
    }
}
