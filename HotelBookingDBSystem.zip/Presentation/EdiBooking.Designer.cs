﻿namespace PhumlaKamnandi2024
{
    partial class frmEditBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEditBooking = new System.Windows.Forms.Label();
            this.lblEnterReservationNo = new System.Windows.Forms.Label();
            this.lblBookingNumber = new System.Windows.Forms.Label();
            this.txtReferenceNo = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEditBooking
            // 
            this.lblEditBooking.AutoSize = true;
            this.lblEditBooking.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblEditBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditBooking.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblEditBooking.Location = new System.Drawing.Point(345, 77);
            this.lblEditBooking.Name = "lblEditBooking";
            this.lblEditBooking.Size = new System.Drawing.Size(145, 25);
            this.lblEditBooking.TabIndex = 1;
            this.lblEditBooking.Text = "Edit Booking";
            // 
            // lblEnterReservationNo
            // 
            this.lblEnterReservationNo.AutoSize = true;
            this.lblEnterReservationNo.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblEnterReservationNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterReservationNo.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblEnterReservationNo.Location = new System.Drawing.Point(279, 149);
            this.lblEnterReservationNo.Name = "lblEnterReservationNo";
            this.lblEnterReservationNo.Size = new System.Drawing.Size(291, 16);
            this.lblEnterReservationNo.TabIndex = 2;
            this.lblEnterReservationNo.Text = "Enter a valid reservation booking number";
            // 
            // lblBookingNumber
            // 
            this.lblBookingNumber.AutoSize = true;
            this.lblBookingNumber.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblBookingNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookingNumber.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblBookingNumber.Location = new System.Drawing.Point(199, 216);
            this.lblBookingNumber.Name = "lblBookingNumber";
            this.lblBookingNumber.Size = new System.Drawing.Size(180, 16);
            this.lblBookingNumber.TabIndex = 3;
            this.lblBookingNumber.Text = "Booking Reference Number :";
            // 
            // txtReferenceNo
            // 
            this.txtReferenceNo.BackColor = System.Drawing.Color.Cornsilk;
            this.txtReferenceNo.Location = new System.Drawing.Point(466, 212);
            this.txtReferenceNo.Name = "txtReferenceNo";
            this.txtReferenceNo.Size = new System.Drawing.Size(160, 20);
            this.txtReferenceNo.TabIndex = 4;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(139, 306);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(611, 306);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 6;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmEditBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtReferenceNo);
            this.Controls.Add(this.lblBookingNumber);
            this.Controls.Add(this.lblEnterReservationNo);
            this.Controls.Add(this.lblEditBooking);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmEditBooking";
            this.Text = "EdiBooking";
            this.Load += new System.EventHandler(this.frmEditBooking_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblEditBooking;
        private System.Windows.Forms.Label lblEnterReservationNo;
        private System.Windows.Forms.Label lblBookingNumber;
        private System.Windows.Forms.TextBox txtReferenceNo;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
    }
}