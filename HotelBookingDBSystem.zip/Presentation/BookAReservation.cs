﻿using PhumlaKamnandi2024.Business;
using PhumlaKamnandi2024.Data;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PhumlaKamnandi2024
{
    public partial class frmBookAReservation : Form
    {
        private Collection<Booking> bookings;
        private BookingController bookingController;

        private Guest currentBooker;

        public frmBookAReservation()
        {
            InitializeComponent();


            lblNumberOfChildren.Visible = false;
            cmbNoOfChildren.Visible = false;
            lblChildrenNB.Visible = false;
            reserverLabel.Visible=false;
        }

        #region Form Load Event

        private void frmBookAReservation_Load(object sender, EventArgs e)
        {

        }


        #endregion
        public void CurrentBooker(Guest guest)
        {
             this.currentBooker= guest;
        }

        #region Button Click Events
        private void button1_Click(object sender, EventArgs e)
        {
            frmMain frmBookAReservation = new frmMain();
            frmBookAReservation.Show();
            this.Hide(); //Hide current form
        }

        private void btnCheck_Click(object sender, EventArgs e)

        {
           
            if (string.IsNullOrEmpty(cmNumberOfGuestsForm2.Text) ||
                string.IsNullOrEmpty(dateTimeIN.Text) ||
                string.IsNullOrEmpty(dateTimeOUT.Text) ||
                string.IsNullOrEmpty(numOfRooms.Text)||
                cmNumberOfGuestsForm2 == null)
            {
                MessageBox.Show("Please fill in all details!","Missing information",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            } // Check if all textboxes and the combo Box is populated if not a message box appears.
            else
            {
                DateTime startDate = dateTimeIN.Value;
                DateTime endDate = dateTimeOUT.Value;

                TimeSpan difference = endDate - startDate;
                int numberOfDays = (int)difference.TotalDays;

                if (numberOfDays < 1)
                {
                    MessageBox.Show("Check-out date must be after check-in date.", "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int rooms = Convert.ToInt32(numOfRooms.SelectedItem);
                decimal totalCost = 0;

               // String totalCost = (450 * rooms).ToString();

                for (DateTime date = startDate; date < endDate; date = date = date.AddDays(1))
                {
                    decimal dailyRate = GetSeasonalRates(date);
                    totalCost += dailyRate * rooms;
                }

                decimal aDeposit = totalCost * 0.10m;

                MessageBox.Show($"Total cost for stay: R{totalCost}\nBooking deposit required: R{aDeposit} ", "MMM");


                bookingController = new BookingController();
                bookings = bookingController.AllBookings;
                int book = bookings.Count;
                String bookingId = "B" + book.ToString("D4"); // Will format as "B000", "B001", etc.

                Booking booking = new Booking(bookingId, currentBooker.GuestID, numOfRooms.Text, dateTimeIN.Text, dateTimeOUT.Text, totalCost.ToString(), "Paid", aDeposit.ToString());

                frmCreditCardDetails frmCreditCardDetails = new frmCreditCardDetails(totalCost.ToString(), aDeposit.ToString());
                frmCreditCardDetails.CurrentBooker(currentBooker);
                frmCreditCardDetails.CurrentBooking(booking);
                frmCreditCardDetails.Show();
                this.Hide();

            } // If all textboxes are populated, the Guest Status form appears

        }


        #endregion

        private void cmNumberOfGuestsForm2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = cmNumberOfGuestsForm2.Text;
            string NoOfChildren = cmbNoOfChildren.Text;

            int maxChildren = 0;

            switch(selectedValue)
            {
                case "1":
                    maxChildren = 3;
                    break;

                case "2":
                    maxChildren = 2;
                    lblChildrenNB.Text = "NB : YOU CAN ONLY CHOOSE UP TO 2 CHILDREN";
                    lblChildrenNB.Visible = true;
                    break;
                case "3":
                    maxChildren = 1;
                    lblChildrenNB.Text = "NB : YOU CAN ONLY CHOOSE UP TO 1 CHILD";
                    lblChildrenNB.Visible = true;
                    break;
                case "4":

                    break;

                default:
                    return;
            }

            lblNumberOfChildren.Visible = true;
            cmbNoOfChildren.Visible = true;

            int childrenCount;
            if(int.TryParse(NoOfChildren, out childrenCount)) 
            {
                if(childrenCount > maxChildren)
                {
                    MessageBox.Show($"YOU CAN ONLY CHOOSE UP TO {maxChildren} CHILD{(maxChildren > 1 ? "REN" : "")}");
                }
            }
        }

        private decimal GetSeasonalRates(DateTime dateTime)
        {
            decimal defaultRate = 450m;

            if (dateTime.Month == 12)
            {
                if(dateTime.Day <= 7)
                {
                    return 550m;
                }
                else if (dateTime.Day >= 8 && dateTime.Day <= 15)
                {
                    return 750;
                }
                else if (dateTime.Day >= 16 && dateTime.Day <= 31)
                {
                    return 995m;
                }
            }

            return 450m;
        }



    }
}
