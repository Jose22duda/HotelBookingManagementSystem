﻿using PhumlaKamnandi2024.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandi2024
{
    
    public partial class frmCancelBooking : Form
    {
        private Booking currentBooking;
        public frmCancelBooking()
        {
            InitializeComponent();
        }
        public void CurrentBooking(Booking booking)
        {
            this.currentBooking = booking;

        }

        private void buttonYes_Click(object sender, EventArgs e)

        {
            try
            {
                BookingController controller = new BookingController(); 
                controller.DataMaintenance(currentBooking,Data.PhumlaKamnandiDB.DBOperation.Delete);
                if (controller.FinalizeChanges(currentBooking, Data.PhumlaKamnandiDB.DBOperation.Delete))
                {
                    MessageBox.Show("Booking Cancelled","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    frmMain frmMain = new frmMain();
                    frmMain.ShowDialog();
                    this.Hide();
                }
                
            }
            catch
            {
                MessageBox.Show("Cancel booking failed. Please try again!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            

        }

        private void buttonNO_Click(object sender, EventArgs e)
        {
            frmMain frmMain = new frmMain();
            frmMain.ShowDialog();
            this.Hide();
        }

        private void frmCancelBooking_Load(object sender, EventArgs e)
        {

        }
    }
}
