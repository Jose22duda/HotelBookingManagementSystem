﻿using PhumlaKamnandi2024.Business;
using PhumlaKamnandi2024.Data;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandi2024
{
    public partial class frmChangeBooking : Form
    {
        private Booking currentBooking;
        public frmChangeBooking(Booking booking)
        {
            InitializeComponent();
            this.currentBooking = booking;
        }
        public void CurrentBooking(Booking booking)
        {
            this.currentBooking = booking;

        }

        #region Form Load Event
        private void frmChangeBooking_Load(object sender, EventArgs e)
        {

        }



        #endregion

        #region Button Click Events
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNumberofGuests.Text) || dtpDateIn.Text == dtpDateOut.Text)
            {
                MessageBox.Show("Please fill out all required fields! The date in and date out cannot be the same.","Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
            }
            else
            {

                DateTime startDate = dtpDateIn.Value;
                DateTime endDate = dtpDateOut.Value;

                TimeSpan difference = endDate - startDate;
                int numberOfDays = (int)difference.TotalDays;

                int rooms = Convert.ToInt32(txtNumberofGuests.Text);
                String totalCost = (450 * rooms).ToString();
                String aDeposit = totalCost.ToString();

                BookingController bookingController = new BookingController();
                Booking booking = new Booking(currentBooking.BookingID, currentBooking.GuestID, txtNumberofGuests.Text, dtpDateIn.Text, dtpDateOut.Text, totalCost, "Not Paid", aDeposit);

                try
                {
                    bookingController.DataMaintenance(booking, PhumlaKamnandiDB.DBOperation.Edit);
                    if (bookingController.FinalizeChanges(booking,PhumlaKamnandiDB.DBOperation.Edit))
                    {
                        MessageBox.Show("Booking change successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        frmMain frmMain = new frmMain();
                        frmMain.Show();
                        this.Close();
                    }

                }
                catch
                {
                    MessageBox.Show("Failed to change booking, Please try again!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmEditBooking frmEditBooking = new frmEditBooking();
            frmEditBooking.Show();
            this.Close();
        }
        #endregion

    }
}
