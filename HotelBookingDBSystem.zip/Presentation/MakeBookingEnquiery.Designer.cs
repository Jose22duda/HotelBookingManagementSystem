﻿namespace PhumlaKamnandi2024
{
    partial class frmMakeBookingEnquiery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMakeBookingEnq = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNameLastForm = new System.Windows.Forms.Label();
            this.lblPhoneLastForm = new System.Windows.Forms.Label();
            this.lblEmailLastForm = new System.Windows.Forms.Label();
            this.lblAddressLastForm = new System.Windows.Forms.Label();
            this.lblBookingLastForm = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.txtNameLastForm = new System.Windows.Forms.TextBox();
            this.txtBookingLastForm = new System.Windows.Forms.TextBox();
            this.txtAddressLastForm = new System.Windows.Forms.TextBox();
            this.txtMailLastForm = new System.Windows.Forms.TextBox();
            this.txtPhoneLastForm = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMakeBookingEnq
            // 
            this.lblMakeBookingEnq.AutoSize = true;
            this.lblMakeBookingEnq.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblMakeBookingEnq.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMakeBookingEnq.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblMakeBookingEnq.Location = new System.Drawing.Point(344, 69);
            this.lblMakeBookingEnq.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMakeBookingEnq.Name = "lblMakeBookingEnq";
            this.lblMakeBookingEnq.Size = new System.Drawing.Size(289, 29);
            this.lblMakeBookingEnq.TabIndex = 1;
            this.lblMakeBookingEnq.Text = "Make Booking Enquiery";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Desktop;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label2.Location = new System.Drawing.Point(23, 154);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Guest Details";
            // 
            // lblNameLastForm
            // 
            this.lblNameLastForm.AutoSize = true;
            this.lblNameLastForm.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblNameLastForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameLastForm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblNameLastForm.Location = new System.Drawing.Point(31, 202);
            this.lblNameLastForm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNameLastForm.Name = "lblNameLastForm";
            this.lblNameLastForm.Size = new System.Drawing.Size(52, 18);
            this.lblNameLastForm.TabIndex = 3;
            this.lblNameLastForm.Text = "Name:";
            // 
            // lblPhoneLastForm
            // 
            this.lblPhoneLastForm.AutoSize = true;
            this.lblPhoneLastForm.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblPhoneLastForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneLastForm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblPhoneLastForm.Location = new System.Drawing.Point(31, 251);
            this.lblPhoneLastForm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneLastForm.Name = "lblPhoneLastForm";
            this.lblPhoneLastForm.Size = new System.Drawing.Size(55, 18);
            this.lblPhoneLastForm.TabIndex = 4;
            this.lblPhoneLastForm.Text = "Phone:";
            // 
            // lblEmailLastForm
            // 
            this.lblEmailLastForm.AutoSize = true;
            this.lblEmailLastForm.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblEmailLastForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailLastForm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblEmailLastForm.Location = new System.Drawing.Point(31, 297);
            this.lblEmailLastForm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmailLastForm.Name = "lblEmailLastForm";
            this.lblEmailLastForm.Size = new System.Drawing.Size(49, 18);
            this.lblEmailLastForm.TabIndex = 5;
            this.lblEmailLastForm.Text = "Email:";
            // 
            // lblAddressLastForm
            // 
            this.lblAddressLastForm.AutoSize = true;
            this.lblAddressLastForm.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblAddressLastForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddressLastForm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblAddressLastForm.Location = new System.Drawing.Point(31, 345);
            this.lblAddressLastForm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddressLastForm.Name = "lblAddressLastForm";
            this.lblAddressLastForm.Size = new System.Drawing.Size(66, 18);
            this.lblAddressLastForm.TabIndex = 6;
            this.lblAddressLastForm.Text = "Address:";
            // 
            // lblBookingLastForm
            // 
            this.lblBookingLastForm.AutoSize = true;
            this.lblBookingLastForm.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblBookingLastForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookingLastForm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblBookingLastForm.Location = new System.Drawing.Point(31, 389);
            this.lblBookingLastForm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBookingLastForm.Name = "lblBookingLastForm";
            this.lblBookingLastForm.Size = new System.Drawing.Size(122, 18);
            this.lblBookingLastForm.TabIndex = 7;
            this.lblBookingLastForm.Text = "Booking Deposit:";
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(781, 449);
            this.btnDone.Margin = new System.Windows.Forms.Padding(4);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(126, 49);
            this.btnDone.TabIndex = 9;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // txtNameLastForm
            // 
            this.txtNameLastForm.BackColor = System.Drawing.Color.Cornsilk;
            this.txtNameLastForm.Location = new System.Drawing.Point(436, 198);
            this.txtNameLastForm.Margin = new System.Windows.Forms.Padding(4);
            this.txtNameLastForm.Name = "txtNameLastForm";
            this.txtNameLastForm.ReadOnly = true;
            this.txtNameLastForm.Size = new System.Drawing.Size(216, 22);
            this.txtNameLastForm.TabIndex = 10;
            // 
            // txtBookingLastForm
            // 
            this.txtBookingLastForm.BackColor = System.Drawing.Color.Cornsilk;
            this.txtBookingLastForm.Location = new System.Drawing.Point(436, 380);
            this.txtBookingLastForm.Margin = new System.Windows.Forms.Padding(4);
            this.txtBookingLastForm.Name = "txtBookingLastForm";
            this.txtBookingLastForm.ReadOnly = true;
            this.txtBookingLastForm.Size = new System.Drawing.Size(216, 22);
            this.txtBookingLastForm.TabIndex = 11;
            // 
            // txtAddressLastForm
            // 
            this.txtAddressLastForm.BackColor = System.Drawing.Color.Cornsilk;
            this.txtAddressLastForm.Location = new System.Drawing.Point(436, 336);
            this.txtAddressLastForm.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddressLastForm.Name = "txtAddressLastForm";
            this.txtAddressLastForm.ReadOnly = true;
            this.txtAddressLastForm.Size = new System.Drawing.Size(216, 22);
            this.txtAddressLastForm.TabIndex = 12;
            // 
            // txtMailLastForm
            // 
            this.txtMailLastForm.BackColor = System.Drawing.Color.Cornsilk;
            this.txtMailLastForm.Location = new System.Drawing.Point(436, 288);
            this.txtMailLastForm.Margin = new System.Windows.Forms.Padding(4);
            this.txtMailLastForm.Name = "txtMailLastForm";
            this.txtMailLastForm.ReadOnly = true;
            this.txtMailLastForm.Size = new System.Drawing.Size(216, 22);
            this.txtMailLastForm.TabIndex = 13;
            // 
            // txtPhoneLastForm
            // 
            this.txtPhoneLastForm.BackColor = System.Drawing.Color.Cornsilk;
            this.txtPhoneLastForm.Location = new System.Drawing.Point(436, 247);
            this.txtPhoneLastForm.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhoneLastForm.Name = "txtPhoneLastForm";
            this.txtPhoneLastForm.ReadOnly = true;
            this.txtPhoneLastForm.Size = new System.Drawing.Size(216, 22);
            this.txtPhoneLastForm.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 124);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmMakeBookingEnquiery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(997, 521);
            this.Controls.Add(this.txtPhoneLastForm);
            this.Controls.Add(this.txtMailLastForm);
            this.Controls.Add(this.txtAddressLastForm);
            this.Controls.Add(this.txtBookingLastForm);
            this.Controls.Add(this.txtNameLastForm);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.lblBookingLastForm);
            this.Controls.Add(this.lblAddressLastForm);
            this.Controls.Add(this.lblEmailLastForm);
            this.Controls.Add(this.lblPhoneLastForm);
            this.Controls.Add(this.lblNameLastForm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblMakeBookingEnq);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMakeBookingEnquiery";
            this.Text = "MakeBookingEnquiery";
            this.Load += new System.EventHandler(this.frmMakeBookingEnquiery_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblMakeBookingEnq;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNameLastForm;
        private System.Windows.Forms.Label lblPhoneLastForm;
        private System.Windows.Forms.Label lblEmailLastForm;
        private System.Windows.Forms.Label lblAddressLastForm;
        private System.Windows.Forms.Label lblBookingLastForm;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.TextBox txtNameLastForm;
        private System.Windows.Forms.TextBox txtBookingLastForm;
        private System.Windows.Forms.TextBox txtAddressLastForm;
        private System.Windows.Forms.TextBox txtMailLastForm;
        private System.Windows.Forms.TextBox txtPhoneLastForm;
    }
}