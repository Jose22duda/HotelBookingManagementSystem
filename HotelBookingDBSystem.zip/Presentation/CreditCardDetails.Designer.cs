﻿namespace PhumlaKamnandi2024
{
    partial class frmCreditCardDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDetails = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblCardNumber = new System.Windows.Forms.Label();
            this.lblExpiryDate = new System.Windows.Forms.Label();
            this.lblSecurityNumber = new System.Windows.Forms.Label();
            this.lblZipCode = new System.Windows.Forms.Label();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.txtNameOnCard = new System.Windows.Forms.TextBox();
            this.txtCardNumber = new System.Windows.Forms.TextBox();
            this.txtSecurityNumber = new System.Windows.Forms.TextBox();
            this.txtZipCode = new System.Windows.Forms.TextBox();
            this.txtYearExDate = new System.Windows.Forms.Label();
            this.lblMonthExDate = new System.Windows.Forms.Label();
            this.btnNextCardFrm = new System.Windows.Forms.Button();
            this.btnBackCardFrm = new System.Windows.Forms.Button();
            this.expirydtp = new System.Windows.Forms.DateTimePicker();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtDeposit = new System.Windows.Forms.TextBox();
            this.lblDeposit = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetails.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblDetails.Location = new System.Drawing.Point(324, 56);
            this.lblDetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(183, 24);
            this.lblDetails.TabIndex = 1;
            this.lblDetails.Text = "Credit Card Details";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblTotalAmount.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblTotalAmount.Location = new System.Drawing.Point(268, 123);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(92, 16);
            this.lblTotalAmount.TabIndex = 2;
            this.lblTotalAmount.Text = "Total Amount :";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblName.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblName.Location = new System.Drawing.Point(268, 253);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(100, 16);
            this.lblName.TabIndex = 3;
            this.lblName.Text = "Name on Card :";
            // 
            // lblCardNumber
            // 
            this.lblCardNumber.AutoSize = true;
            this.lblCardNumber.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblCardNumber.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblCardNumber.Location = new System.Drawing.Point(267, 302);
            this.lblCardNumber.Name = "lblCardNumber";
            this.lblCardNumber.Size = new System.Drawing.Size(93, 16);
            this.lblCardNumber.TabIndex = 4;
            this.lblCardNumber.Text = "Card Number :";
            // 
            // lblExpiryDate
            // 
            this.lblExpiryDate.AutoSize = true;
            this.lblExpiryDate.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblExpiryDate.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblExpiryDate.Location = new System.Drawing.Point(267, 375);
            this.lblExpiryDate.Name = "lblExpiryDate";
            this.lblExpiryDate.Size = new System.Drawing.Size(82, 16);
            this.lblExpiryDate.TabIndex = 5;
            this.lblExpiryDate.Text = "Expiry Date :";
            // 
            // lblSecurityNumber
            // 
            this.lblSecurityNumber.AutoSize = true;
            this.lblSecurityNumber.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblSecurityNumber.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblSecurityNumber.Location = new System.Drawing.Point(268, 422);
            this.lblSecurityNumber.Name = "lblSecurityNumber";
            this.lblSecurityNumber.Size = new System.Drawing.Size(112, 16);
            this.lblSecurityNumber.TabIndex = 6;
            this.lblSecurityNumber.Text = "Security Number :";
            // 
            // lblZipCode
            // 
            this.lblZipCode.AutoSize = true;
            this.lblZipCode.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblZipCode.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblZipCode.Location = new System.Drawing.Point(267, 486);
            this.lblZipCode.Name = "lblZipCode";
            this.lblZipCode.Size = new System.Drawing.Size(110, 16);
            this.lblZipCode.TabIndex = 7;
            this.lblZipCode.Text = "Zip/Postal Code :";
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.BackColor = System.Drawing.Color.Cornsilk;
            this.txtTotalAmount.Location = new System.Drawing.Point(447, 120);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.ReadOnly = true;
            this.txtTotalAmount.Size = new System.Drawing.Size(100, 22);
            this.txtTotalAmount.TabIndex = 8;
            // 
            // txtNameOnCard
            // 
            this.txtNameOnCard.BackColor = System.Drawing.Color.Cornsilk;
            this.txtNameOnCard.Location = new System.Drawing.Point(448, 250);
            this.txtNameOnCard.Name = "txtNameOnCard";
            this.txtNameOnCard.Size = new System.Drawing.Size(100, 22);
            this.txtNameOnCard.TabIndex = 9;
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.BackColor = System.Drawing.Color.Cornsilk;
            this.txtCardNumber.Location = new System.Drawing.Point(446, 296);
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Size = new System.Drawing.Size(100, 22);
            this.txtCardNumber.TabIndex = 10;
            // 
            // txtSecurityNumber
            // 
            this.txtSecurityNumber.BackColor = System.Drawing.Color.Cornsilk;
            this.txtSecurityNumber.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtSecurityNumber.Location = new System.Drawing.Point(446, 419);
            this.txtSecurityNumber.Name = "txtSecurityNumber";
            this.txtSecurityNumber.Size = new System.Drawing.Size(100, 22);
            this.txtSecurityNumber.TabIndex = 12;
            // 
            // txtZipCode
            // 
            this.txtZipCode.BackColor = System.Drawing.Color.Cornsilk;
            this.txtZipCode.Location = new System.Drawing.Point(447, 483);
            this.txtZipCode.Name = "txtZipCode";
            this.txtZipCode.Size = new System.Drawing.Size(100, 22);
            this.txtZipCode.TabIndex = 13;
            // 
            // txtYearExDate
            // 
            this.txtYearExDate.AutoSize = true;
            this.txtYearExDate.BackColor = System.Drawing.SystemColors.Desktop;
            this.txtYearExDate.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.txtYearExDate.Location = new System.Drawing.Point(511, 336);
            this.txtYearExDate.Name = "txtYearExDate";
            this.txtYearExDate.Size = new System.Drawing.Size(36, 16);
            this.txtYearExDate.TabIndex = 15;
            this.txtYearExDate.Text = "Year";
            // 
            // lblMonthExDate
            // 
            this.lblMonthExDate.AutoSize = true;
            this.lblMonthExDate.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblMonthExDate.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblMonthExDate.Location = new System.Drawing.Point(443, 336);
            this.lblMonthExDate.Name = "lblMonthExDate";
            this.lblMonthExDate.Size = new System.Drawing.Size(46, 16);
            this.lblMonthExDate.TabIndex = 16;
            this.lblMonthExDate.Text = "Month ";
            // 
            // btnNextCardFrm
            // 
            this.btnNextCardFrm.Location = new System.Drawing.Point(742, 526);
            this.btnNextCardFrm.Name = "btnNextCardFrm";
            this.btnNextCardFrm.Size = new System.Drawing.Size(75, 23);
            this.btnNextCardFrm.TabIndex = 20;
            this.btnNextCardFrm.Text = "Next";
            this.btnNextCardFrm.UseVisualStyleBackColor = true;
            this.btnNextCardFrm.Click += new System.EventHandler(this.btnNextCardFrm_Click);
            // 
            // btnBackCardFrm
            // 
            this.btnBackCardFrm.Location = new System.Drawing.Point(38, 526);
            this.btnBackCardFrm.Name = "btnBackCardFrm";
            this.btnBackCardFrm.Size = new System.Drawing.Size(75, 23);
            this.btnBackCardFrm.TabIndex = 21;
            this.btnBackCardFrm.Text = "Back";
            this.btnBackCardFrm.UseVisualStyleBackColor = true;
            this.btnBackCardFrm.Click += new System.EventHandler(this.btnBackCardFrm_Click);
            // 
            // expirydtp
            // 
            this.expirydtp.CustomFormat = "MM yyyy";
            this.expirydtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.expirydtp.Location = new System.Drawing.Point(448, 370);
            this.expirydtp.Name = "expirydtp";
            this.expirydtp.Size = new System.Drawing.Size(99, 22);
            this.expirydtp.TabIndex = 22;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.Desktop;
            this.pictureBox3.Image = global::PhumlaKamnandi2024.Properties.Resources.visa_logo;
            this.pictureBox3.Location = new System.Drawing.Point(572, 201);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(125, 36);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 19;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Desktop;
            this.pictureBox2.Image = global::PhumlaKamnandi2024.Properties.Resources.americanexpress;
            this.pictureBox2.Location = new System.Drawing.Point(703, 201);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(87, 36);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(152, 127);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // txtDeposit
            // 
            this.txtDeposit.BackColor = System.Drawing.Color.Cornsilk;
            this.txtDeposit.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtDeposit.Location = new System.Drawing.Point(447, 187);
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.ReadOnly = true;
            this.txtDeposit.Size = new System.Drawing.Size(100, 22);
            this.txtDeposit.TabIndex = 23;
            // 
            // lblDeposit
            // 
            this.lblDeposit.AutoSize = true;
            this.lblDeposit.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblDeposit.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblDeposit.Location = new System.Drawing.Point(268, 190);
            this.lblDeposit.Name = "lblDeposit";
            this.lblDeposit.Size = new System.Drawing.Size(121, 16);
            this.lblDeposit.TabIndex = 24;
            this.lblDeposit.Text = "Deposit (payable) :";
            // 
            // frmCreditCardDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(920, 604);
            this.Controls.Add(this.lblDeposit);
            this.Controls.Add(this.txtDeposit);
            this.Controls.Add(this.expirydtp);
            this.Controls.Add(this.btnBackCardFrm);
            this.Controls.Add(this.btnNextCardFrm);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblMonthExDate);
            this.Controls.Add(this.txtYearExDate);
            this.Controls.Add(this.txtZipCode);
            this.Controls.Add(this.txtSecurityNumber);
            this.Controls.Add(this.txtCardNumber);
            this.Controls.Add(this.txtNameOnCard);
            this.Controls.Add(this.txtTotalAmount);
            this.Controls.Add(this.lblZipCode);
            this.Controls.Add(this.lblSecurityNumber);
            this.Controls.Add(this.lblExpiryDate);
            this.Controls.Add(this.lblCardNumber);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblTotalAmount);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmCreditCardDetails";
            this.Text = "CreditCardDetails";
            this.Load += new System.EventHandler(this.frmCreditCardDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblCardNumber;
        private System.Windows.Forms.Label lblExpiryDate;
        private System.Windows.Forms.Label lblSecurityNumber;
        private System.Windows.Forms.Label lblZipCode;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.TextBox txtNameOnCard;
        private System.Windows.Forms.TextBox txtCardNumber;
        private System.Windows.Forms.TextBox txtSecurityNumber;
        private System.Windows.Forms.TextBox txtZipCode;
        private System.Windows.Forms.Label txtYearExDate;
        private System.Windows.Forms.Label lblMonthExDate;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnNextCardFrm;
        private System.Windows.Forms.Button btnBackCardFrm;
        private System.Windows.Forms.DateTimePicker expirydtp;
        private System.Windows.Forms.TextBox txtDeposit;
        private System.Windows.Forms.Label lblDeposit;
    }
}