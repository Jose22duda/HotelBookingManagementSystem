﻿using PhumlaKamnandi2024.Presentation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhumlaKamnandi2024.Business;
using PhumlaKamnandi2024.Data;
using System.Xml.Linq;
using System.Collections.ObjectModel;

namespace PhumlaKamnandi2024
{
    public partial class frmCreditCardDetails : Form
    {
        Booking currentBooking;
        Guest currentBooker;
        public frmCreditCardDetails(String total, string aDeposit)

        {
            
            InitializeComponent();
            txtTotalAmount.Text = total;
            txtDeposit.Text= aDeposit;
        }
        public void CurrentBooker(Guest guest)
        {
            this.currentBooker = guest;
        }
        public void CurrentBooking(Booking booking)
        {
            this.currentBooking = booking;
        }
        #region Form Load Event
        private void frmCreditCardDetails_Load(object sender, EventArgs e)
        {

        }


        #endregion

        #region Button Click Events
        private void btnNextCardFrm_Click(object sender, EventArgs e)
        {
            //validations /error handling
            if (string.IsNullOrEmpty(txtNameOnCard.Text) ||
                string.IsNullOrEmpty(txtCardNumber.Text) ||
                string.IsNullOrEmpty(txtSecurityNumber.Text) ||
                string.IsNullOrEmpty(expirydtp.Text) ||
                string.IsNullOrEmpty(txtYearExDate.Text) || 
                string.IsNullOrEmpty(txtZipCode.Text) ||
                string.IsNullOrEmpty(txtDeposit.Text))
            {
                MessageBox.Show("Please fill in all details!", "Missing information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            if(!System.Text.RegularExpressions.Regex.IsMatch(txtCardNumber.Text,@"^\d{16}$"))
            {
                MessageBox.Show("Card number must be exactly 16 digits!","Invalid Card Number",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(!System.Text.RegularExpressions.Regex.IsMatch(txtSecurityNumber.Text, @"^\d{3}"))
            {
                MessageBox.Show("Security Number (CVV) must be 3 numbers!","Invalid Secuity Number ",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            if(!System.Text.RegularExpressions.Regex.IsMatch(txtZipCode.Text, @"^\d{4}"))
            {
                MessageBox.Show("Zip Code must be 4 numbers!", "Invalid Zip Code ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(!System.Text.RegularExpressions.Regex.IsMatch(txtNameOnCard.Text,@"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Invalid name", "INvalid Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            else
            {


                try
                {
                    BookingController bookingController = new BookingController();
                    GuestController guestController = new GuestController();

                    bool contained = false;
                    Collection<Guest> guests = guestController.AllGuests;

                    foreach (Guest guest in guests)
                    {
                        if (guest.GuestID == currentBooker.GuestID)
                        {
                            contained = true; break;
                        }

                    }
                    if (contained)
                    {
                        bookingController.DataMaintenance(currentBooking, PhumlaKamnandiDB.DBOperation.Add);
                        // Commit the changes to the database
                        if (bookingController.FinalizeChanges(currentBooking, Data.PhumlaKamnandiDB.DBOperation.Add))
                        {
                            MessageBox.Show("Booking Complete","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                            frmBookingComplete frmBookingComplete = new frmBookingComplete(currentBooker.Name, currentBooking.BookingID, currentBooking.CheckInDate, currentBooking.CheckOutDate);
                            frmBookingComplete.CurrentBooking(currentBooking);
                            frmBookingComplete.Show();
                            this.Hide();
                        }
                        else
                        {

                            MessageBox.Show("Error With Finalizing Booking. Please try again!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        bookingController.DataMaintenance(currentBooking, PhumlaKamnandiDB.DBOperation.Add);
                        guestController.DataMaintenance(currentBooker, PhumlaKamnandiDB.DBOperation.Add);

                        if (bookingController.FinalizeChanges(currentBooking, Data.PhumlaKamnandiDB.DBOperation.Add) && guestController.FinalizeChanges(currentBooker))
                        {
                            MessageBox.Show("Booking Complete", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            frmBookingComplete frmBookingComplete = new frmBookingComplete(currentBooker.Name, currentBooking.BookingID, currentBooking.CheckInDate, currentBooking.CheckOutDate);
                            frmBookingComplete.CurrentBooking(currentBooking);
                            frmBookingComplete.Show();
                            this.Hide();
                        }
                        else
                        {

                            MessageBox.Show("Error With Finalizing Booking","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        }

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error With Finalizing Booking: " + ex.Message,"Error",MessageBoxButtons.OK);
                }

            }
        }

        private void btnBackCardFrm_Click(object sender, EventArgs e)
        {
            frmReturningGuestDetails frmReturningGuestDetails = new frmReturningGuestDetails();
            frmReturningGuestDetails.Show();
            this.Hide();
        }
        #endregion

        private void txtMonthExDate_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
