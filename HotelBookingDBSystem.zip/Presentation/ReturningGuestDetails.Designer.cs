﻿namespace PhumlaKamnandi2024.Presentation
{
    partial class frmReturningGuestDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExistingGuestDetails = new System.Windows.Forms.Label();
            this.lblGuestName = new System.Windows.Forms.Label();
            this.lblIDNumber = new System.Windows.Forms.Label();
            this.txtIDNumber = new System.Windows.Forms.TextBox();
            this.txtGuestName = new System.Windows.Forms.TextBox();
            this.btnRetrieve = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblExistingGuestDetails
            // 
            this.lblExistingGuestDetails.AutoSize = true;
            this.lblExistingGuestDetails.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblExistingGuestDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExistingGuestDetails.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblExistingGuestDetails.Location = new System.Drawing.Point(319, 66);
            this.lblExistingGuestDetails.Name = "lblExistingGuestDetails";
            this.lblExistingGuestDetails.Size = new System.Drawing.Size(212, 24);
            this.lblExistingGuestDetails.TabIndex = 1;
            this.lblExistingGuestDetails.Text = "Existing Guest Details";
            // 
            // lblGuestName
            // 
            this.lblGuestName.AutoSize = true;
            this.lblGuestName.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblGuestName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuestName.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblGuestName.Location = new System.Drawing.Point(266, 236);
            this.lblGuestName.Name = "lblGuestName";
            this.lblGuestName.Size = new System.Drawing.Size(88, 16);
            this.lblGuestName.TabIndex = 2;
            this.lblGuestName.Text = "Guest Name :";
            // 
            // lblIDNumber
            // 
            this.lblIDNumber.AutoSize = true;
            this.lblIDNumber.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblIDNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDNumber.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblIDNumber.Location = new System.Drawing.Point(266, 315);
            this.lblIDNumber.Name = "lblIDNumber";
            this.lblIDNumber.Size = new System.Drawing.Size(77, 16);
            this.lblIDNumber.TabIndex = 3;
            this.lblIDNumber.Text = "ID Number :";
            // 
            // txtIDNumber
            // 
            this.txtIDNumber.BackColor = System.Drawing.Color.Cornsilk;
            this.txtIDNumber.Location = new System.Drawing.Point(440, 311);
            this.txtIDNumber.Name = "txtIDNumber";
            this.txtIDNumber.Size = new System.Drawing.Size(119, 20);
            this.txtIDNumber.TabIndex = 4;
            // 
            // txtGuestName
            // 
            this.txtGuestName.BackColor = System.Drawing.Color.Cornsilk;
            this.txtGuestName.Location = new System.Drawing.Point(440, 232);
            this.txtGuestName.Name = "txtGuestName";
            this.txtGuestName.Size = new System.Drawing.Size(119, 20);
            this.txtGuestName.TabIndex = 5;
            // 
            // btnRetrieve
            // 
            this.btnRetrieve.Location = new System.Drawing.Point(624, 423);
            this.btnRetrieve.Name = "btnRetrieve";
            this.btnRetrieve.Size = new System.Drawing.Size(75, 23);
            this.btnRetrieve.TabIndex = 6;
            this.btnRetrieve.Text = "Retrieve";
            this.btnRetrieve.UseVisualStyleBackColor = true;
            this.btnRetrieve.Click += new System.EventHandler(this.btnRetrieve_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(85, 423);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 165);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmReturningGuestDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 522);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnRetrieve);
            this.Controls.Add(this.txtGuestName);
            this.Controls.Add(this.txtIDNumber);
            this.Controls.Add(this.lblIDNumber);
            this.Controls.Add(this.lblGuestName);
            this.Controls.Add(this.lblExistingGuestDetails);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmReturningGuestDetails";
            this.Text = "Returning Guest Details";
            this.Load += new System.EventHandler(this.frmReturningGuestDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblExistingGuestDetails;
        private System.Windows.Forms.Label lblGuestName;
        private System.Windows.Forms.Label lblIDNumber;
        private System.Windows.Forms.TextBox txtIDNumber;
        private System.Windows.Forms.TextBox txtGuestName;
        private System.Windows.Forms.Button btnRetrieve;
        private System.Windows.Forms.Button btnBack;
    }
}