﻿using PhumlaKamnandi2024.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandi2024
{
    public partial class frmMakeBookingEnquiery : Form
    {
        public frmMakeBookingEnquiery()
        {
            InitializeComponent();
        }
        public void CurrentBooking(Booking booking)
        {
            GuestController controller = new GuestController();
            foreach (Guest guest in controller.AllGuests)
            {
                if (guest.GuestID == booking.GuestID)
                {
                    txtNameLastForm.Text = guest.Name;
                    txtPhoneLastForm.Text = guest.ContactNumber;
                    txtMailLastForm.Text= guest.Email;
                    txtAddressLastForm.Text = guest.Address ;
                    txtBookingLastForm.Text = booking.TotalAmount;
                    break;
                }
            }

        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            frmMain frmMain = new frmMain();
            frmMain.Show();
            this.Close();
        }

        private void frmMakeBookingEnquiery_Load(object sender, EventArgs e)
        {

        }
    }
}
