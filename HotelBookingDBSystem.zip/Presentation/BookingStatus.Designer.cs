﻿namespace PhumlaKamnandi2024
{
    partial class BookingStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookingStatus = new System.Windows.Forms.Label();
            this.lblUpdatedDetails = new System.Windows.Forms.Label();
            this.lblDepositStatus = new System.Windows.Forms.Label();
            this.txtDepositStatus = new System.Windows.Forms.TextBox();
            this.txtUpdatedDetails = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnBackToHpage = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBookingStatus
            // 
            this.lblBookingStatus.AutoSize = true;
            this.lblBookingStatus.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblBookingStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookingStatus.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblBookingStatus.Location = new System.Drawing.Point(412, 76);
            this.lblBookingStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBookingStatus.Name = "lblBookingStatus";
            this.lblBookingStatus.Size = new System.Drawing.Size(211, 31);
            this.lblBookingStatus.TabIndex = 1;
            this.lblBookingStatus.Text = "Booking Status";
            // 
            // lblUpdatedDetails
            // 
            this.lblUpdatedDetails.AutoSize = true;
            this.lblUpdatedDetails.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblUpdatedDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdatedDetails.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblUpdatedDetails.Location = new System.Drawing.Point(259, 241);
            this.lblUpdatedDetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUpdatedDetails.Name = "lblUpdatedDetails";
            this.lblUpdatedDetails.Size = new System.Drawing.Size(224, 20);
            this.lblUpdatedDetails.TabIndex = 2;
            this.lblUpdatedDetails.Text = "Booking details last updated:";
            // 
            // lblDepositStatus
            // 
            this.lblDepositStatus.AutoSize = true;
            this.lblDepositStatus.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblDepositStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepositStatus.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblDepositStatus.Location = new System.Drawing.Point(259, 356);
            this.lblDepositStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDepositStatus.Name = "lblDepositStatus";
            this.lblDepositStatus.Size = new System.Drawing.Size(137, 20);
            this.lblDepositStatus.TabIndex = 3;
            this.lblDepositStatus.Text = "Booking Deposit:";
            // 
            // txtDepositStatus
            // 
            this.txtDepositStatus.BackColor = System.Drawing.Color.Cornsilk;
            this.txtDepositStatus.Location = new System.Drawing.Point(541, 347);
            this.txtDepositStatus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDepositStatus.Name = "txtDepositStatus";
            this.txtDepositStatus.ReadOnly = true;
            this.txtDepositStatus.Size = new System.Drawing.Size(167, 22);
            this.txtDepositStatus.TabIndex = 4;
            // 
            // txtUpdatedDetails
            // 
            this.txtUpdatedDetails.BackColor = System.Drawing.Color.Cornsilk;
            this.txtUpdatedDetails.Location = new System.Drawing.Point(541, 236);
            this.txtUpdatedDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtUpdatedDetails.Name = "txtUpdatedDetails";
            this.txtUpdatedDetails.ReadOnly = true;
            this.txtUpdatedDetails.Size = new System.Drawing.Size(167, 22);
            this.txtUpdatedDetails.TabIndex = 5;
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(96, 464);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 28);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btnBackToHpage
            // 
            this.btnBackToHpage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackToHpage.Location = new System.Drawing.Point(732, 464);
            this.btnBackToHpage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBackToHpage.Name = "btnBackToHpage";
            this.btnBackToHpage.Size = new System.Drawing.Size(193, 28);
            this.btnBackToHpage.TabIndex = 7;
            this.btnBackToHpage.Text = "Back to home page";
            this.btnBackToHpage.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(212, 166);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // BookingStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1009, 554);
            this.Controls.Add(this.btnBackToHpage);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtUpdatedDetails);
            this.Controls.Add(this.txtDepositStatus);
            this.Controls.Add(this.lblDepositStatus);
            this.Controls.Add(this.lblUpdatedDetails);
            this.Controls.Add(this.lblBookingStatus);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "BookingStatus";
            this.Text = "BookingStatus";
            this.Load += new System.EventHandler(this.BookingStatus_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblBookingStatus;
        private System.Windows.Forms.Label lblUpdatedDetails;
        private System.Windows.Forms.Label lblDepositStatus;
        private System.Windows.Forms.TextBox txtDepositStatus;
        private System.Windows.Forms.TextBox txtUpdatedDetails;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnBackToHpage;
    }
}