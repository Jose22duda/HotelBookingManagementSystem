﻿using PhumlaKamnandi2024.Business;
using PhumlaKamnandi2024.Data;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PhumlaKamnandi2024.Presentation
{
    public partial class frmReturningGuestDetails : Form
    {
        public frmReturningGuestDetails()
        {
            InitializeComponent();
        }

        #region Form Load Event
        private void frmReturningGuestDetails_Load(object sender, EventArgs e)
        {

        }


        #endregion

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            //Validations and Error Handling
            if(string.IsNullOrEmpty(txtGuestName.Text) ||
                string.IsNullOrEmpty(txtIDNumber.Text))
            {
                MessageBox.Show("Please fill in all required details","Missing Information",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtGuestName.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Invalid name", "Invalid Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtIDNumber.Text, @"^\d{13}$"))
            {
                MessageBox.Show("ID number not valid, Please enter a valid ID number!", "Invalid Card Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                if ((txtIDNumber.Text).Length != 13 )
                {
                        MessageBox.Show("ID number not valid, Please enter a valid ID number!","Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);

                }
                else
                {
                    frmBookAReservation frmBook = new frmBookAReservation();
                    bool contained = false;
                    GuestController guestController = new GuestController();
                    Collection<Guest> guests = guestController.AllGuests;
                    try
                    {
                        foreach (Guest guest in guests)
                        {
                            if ( guest.GuestID == txtIDNumber.Text)
                            {
                                frmBook.CurrentBooker(guest);
                                contained = true; break;
                            }
                            
                        }
                        if (contained)
                        {
                            MessageBox.Show("Guest " + txtGuestName.Text + " is in the database.","Note",MessageBoxButtons.OK,MessageBoxIcon.Information);                          
                            frmBook.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show( txtGuestName.Text +" NOT FOUND in the database.","Note",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                            frmNewGuest frmNewGuest = new frmNewGuest();
                            frmNewGuest.Show();
                            this.Hide();

                        }
                            


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error adding guest: " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                }
   

            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmGuestStatus frmGuestStatus = new frmGuestStatus();
            frmGuestStatus.Show();
            this.Hide();
        }
    }
}
