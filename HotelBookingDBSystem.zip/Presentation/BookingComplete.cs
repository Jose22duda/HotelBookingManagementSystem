﻿using PhumlaKamnandi2024.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandi2024
{
    public partial class frmBookingComplete : Form
    {
        private String bookerName;
        private String bookingID;
        private String datein;
        private String dateout;
        Booking booking;
        public frmBookingComplete(string bookerName, string bookingID,String datein,String dateout)
        {
            InitializeComponent();
            txtGuestName.Text = bookerName;
            textBox3.Text = bookingID;
            textBox4.Text = datein;
            textBox1.Text = dateout;
        }

        public void CurrentBooking(Booking booking)
        {
            this.booking = booking;
        }

        #region Form Load Event
        private void frmBookingComplete_Load(object sender, EventArgs e)
        {

        }

        #endregion

        private void btnDone_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you.", "Finish",MessageBoxButtons.OK,MessageBoxIcon.Information);
            frmMain frmMain = new frmMain();
            frmMain.Show();
            this.Close();
        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            String booking_str = booking.ToString();
            MessageBox.Show("Email sent with following information" + "\n" + booking_str,"Email Sent successfully",MessageBoxButtons.OK,MessageBoxIcon.Information);
            
        }

        private void lblSpace_Click(object sender, EventArgs e)
        {

        }
    }
}
