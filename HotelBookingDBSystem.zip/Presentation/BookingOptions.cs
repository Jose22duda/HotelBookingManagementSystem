﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhumlaKamnandi2024.Business;
using PhumlaKamnandi2024.Data;

namespace PhumlaKamnandi2024
{
    public partial class frmBookingOptions : Form
    {
        private Booking currentBooking;
        public frmBookingOptions()
        {
            InitializeComponent();
        }

        #region Form Load Event
        private void frmBookingOptions_Load(object sender, EventArgs e)
        {

        }

        #endregion

        public void CurrentBooking(Booking booking)
        {
            this.currentBooking = booking;

        }
        private void btnChangeBooking_Click(object sender, EventArgs e)
        {
            frmChangeBooking frmChangeBooking = new frmChangeBooking(currentBooking);
            frmChangeBooking.Show();
            this.Close();
        }

        private void btnCancelBooking_Click(object sender, EventArgs e)
        {
            frmCancelBooking frmCancelBooking = new frmCancelBooking();
            frmCancelBooking.CurrentBooking(currentBooking);
            frmCancelBooking.Show();
            this.Close();

        }

        private void btnEnquiry_Click(object sender, EventArgs e)
        {
            frmMakeBookingEnquiery frmMakeBookingEnquiry = new frmMakeBookingEnquiery();
            frmMakeBookingEnquiry.CurrentBooking(currentBooking);
            frmMakeBookingEnquiry.Show();
            this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmEditBooking frmEditBooking = new frmEditBooking();
            frmEditBooking.Show();
            this.Close();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            frmMain frmMain = new frmMain();
            frmMain.Show();
            this.Close();
        }
    }
}
