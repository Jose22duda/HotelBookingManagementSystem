﻿namespace PhumlaKamnandi2024
{
    partial class frmChangeBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblChangeBooking = new System.Windows.Forms.Label();
            this.lblNoOfGuests = new System.Windows.Forms.Label();
            this.lblDateIn = new System.Windows.Forms.Label();
            this.lblDateOut = new System.Windows.Forms.Label();
            this.dtpDateIn = new System.Windows.Forms.DateTimePicker();
            this.dtpDateOut = new System.Windows.Forms.DateTimePicker();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtNumberofGuests = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblChangeBooking
            // 
            this.lblChangeBooking.AutoSize = true;
            this.lblChangeBooking.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblChangeBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeBooking.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblChangeBooking.Location = new System.Drawing.Point(421, 105);
            this.lblChangeBooking.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChangeBooking.Name = "lblChangeBooking";
            this.lblChangeBooking.Size = new System.Drawing.Size(228, 31);
            this.lblChangeBooking.TabIndex = 1;
            this.lblChangeBooking.Text = "Change Booking";
            // 
            // lblNoOfGuests
            // 
            this.lblNoOfGuests.AutoSize = true;
            this.lblNoOfGuests.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblNoOfGuests.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfGuests.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblNoOfGuests.Location = new System.Drawing.Point(359, 209);
            this.lblNoOfGuests.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNoOfGuests.Name = "lblNoOfGuests";
            this.lblNoOfGuests.Size = new System.Drawing.Size(155, 20);
            this.lblNoOfGuests.TabIndex = 2;
            this.lblNoOfGuests.Text = "Number of Rooms :";
            // 
            // lblDateIn
            // 
            this.lblDateIn.AutoSize = true;
            this.lblDateIn.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblDateIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateIn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblDateIn.Location = new System.Drawing.Point(359, 270);
            this.lblDateIn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateIn.Name = "lblDateIn";
            this.lblDateIn.Size = new System.Drawing.Size(73, 20);
            this.lblDateIn.TabIndex = 3;
            this.lblDateIn.Text = "Date in :";
            // 
            // lblDateOut
            // 
            this.lblDateOut.AutoSize = true;
            this.lblDateOut.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblDateOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateOut.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblDateOut.Location = new System.Drawing.Point(359, 319);
            this.lblDateOut.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOut.Name = "lblDateOut";
            this.lblDateOut.Size = new System.Drawing.Size(83, 20);
            this.lblDateOut.TabIndex = 4;
            this.lblDateOut.Text = "Date out :";
            // 
            // dtpDateIn
            // 
            this.dtpDateIn.CalendarMonthBackground = System.Drawing.Color.Cornsilk;
            this.dtpDateIn.Location = new System.Drawing.Point(572, 262);
            this.dtpDateIn.Margin = new System.Windows.Forms.Padding(4);
            this.dtpDateIn.Name = "dtpDateIn";
            this.dtpDateIn.Size = new System.Drawing.Size(260, 22);
            this.dtpDateIn.TabIndex = 8;
            // 
            // dtpDateOut
            // 
            this.dtpDateOut.CalendarMonthBackground = System.Drawing.Color.Cornsilk;
            this.dtpDateOut.Location = new System.Drawing.Point(572, 319);
            this.dtpDateOut.Margin = new System.Windows.Forms.Padding(4);
            this.dtpDateOut.Name = "dtpDateOut";
            this.dtpDateOut.Size = new System.Drawing.Size(265, 22);
            this.dtpDateOut.TabIndex = 9;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(852, 455);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(4);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(136, 28);
            this.btnConfirm.TabIndex = 11;
            this.btnConfirm.Text = "Confirm Changes";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(160, 455);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 28);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(217, 162);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // txtNumberofGuests
            // 
            this.txtNumberofGuests.FormattingEnabled = true;
            this.txtNumberofGuests.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.txtNumberofGuests.Location = new System.Drawing.Point(572, 207);
            this.txtNumberofGuests.Name = "txtNumberofGuests";
            this.txtNumberofGuests.Size = new System.Drawing.Size(185, 24);
            this.txtNumberofGuests.TabIndex = 13;
            // 
            // frmChangeBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.txtNumberofGuests);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.dtpDateOut);
            this.Controls.Add(this.dtpDateIn);
            this.Controls.Add(this.lblDateOut);
            this.Controls.Add(this.lblDateIn);
            this.Controls.Add(this.lblNoOfGuests);
            this.Controls.Add(this.lblChangeBooking);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmChangeBooking";
            this.Text = "ChangeBooking";
            this.Load += new System.EventHandler(this.frmChangeBooking_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblChangeBooking;
        private System.Windows.Forms.Label lblNoOfGuests;
        private System.Windows.Forms.Label lblDateIn;
        private System.Windows.Forms.Label lblDateOut;
        private System.Windows.Forms.DateTimePicker dtpDateIn;
        private System.Windows.Forms.DateTimePicker dtpDateOut;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ComboBox txtNumberofGuests;
    }
}