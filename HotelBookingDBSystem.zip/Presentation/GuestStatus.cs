﻿using PhumlaKamnandi2024.Presentation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandi2024
{
    public partial class frmGuestStatus : Form
    {
        public frmGuestStatus()
        {
            InitializeComponent();
        }

        #region Form Load Event
        private void frmGuestStatus_Load(object sender, EventArgs e)
        {

        }
        #endregion

        #region ButtonClick Events
        private void rbtnNewGuest_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnExistingGuest_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            if (rbtnNewGuest.Checked)
            {
                frmNewGuest frmNewGuest = new frmNewGuest();
                frmNewGuest.Show();
                this.Hide();
            }
            else if (rbtnExistingGuest.Checked)
            {
                frmReturningGuestDetails frmReturningGuestDetails = new frmReturningGuestDetails();
                frmReturningGuestDetails.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Choose an option","Warning",MessageBoxButtons.RetryCancel,MessageBoxIcon.Warning);
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            frmBookAReservation frmBookAReservation = new frmBookAReservation();
            frmBookAReservation.Show();
            this.Hide();
        }

        #endregion
    }
}
