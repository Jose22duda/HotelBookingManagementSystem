﻿namespace PhumlaKamnandi2024
{
    partial class frmBookingComplete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblBooking = new System.Windows.Forms.Label();
            this.lblGuestName = new System.Windows.Forms.Label();
            this.lblReservationNo = new System.Windows.Forms.Label();
            this.lblDates = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtGuestName = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lblSpace = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.btnEmail = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(216, 160);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblBooking
            // 
            this.lblBooking.AutoSize = true;
            this.lblBooking.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBooking.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblBooking.Location = new System.Drawing.Point(416, 71);
            this.lblBooking.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBooking.Name = "lblBooking";
            this.lblBooking.Size = new System.Drawing.Size(251, 31);
            this.lblBooking.TabIndex = 1;
            this.lblBooking.Text = "Booking Complete";
            // 
            // lblGuestName
            // 
            this.lblGuestName.AutoSize = true;
            this.lblGuestName.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblGuestName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuestName.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblGuestName.Location = new System.Drawing.Point(247, 193);
            this.lblGuestName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuestName.Name = "lblGuestName";
            this.lblGuestName.Size = new System.Drawing.Size(113, 20);
            this.lblGuestName.TabIndex = 2;
            this.lblGuestName.Text = "Guest Name :";
            // 
            // lblReservationNo
            // 
            this.lblReservationNo.AutoSize = true;
            this.lblReservationNo.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblReservationNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReservationNo.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblReservationNo.Location = new System.Drawing.Point(247, 261);
            this.lblReservationNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReservationNo.Name = "lblReservationNo";
            this.lblReservationNo.Size = new System.Drawing.Size(254, 20);
            this.lblReservationNo.TabIndex = 3;
            this.lblReservationNo.Text = "Reservation Reference Number :";
            // 
            // lblDates
            // 
            this.lblDates.AutoSize = true;
            this.lblDates.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblDates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDates.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblDates.Location = new System.Drawing.Point(247, 319);
            this.lblDates.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDates.Name = "lblDates";
            this.lblDates.Size = new System.Drawing.Size(64, 20);
            this.lblDates.TabIndex = 4;
            this.lblDates.Text = "Dates :";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox1.Location = new System.Drawing.Point(855, 319);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(168, 22);
            this.textBox1.TabIndex = 5;
            // 
            // txtGuestName
            // 
            this.txtGuestName.BackColor = System.Drawing.Color.Cornsilk;
            this.txtGuestName.Location = new System.Drawing.Point(557, 188);
            this.txtGuestName.Margin = new System.Windows.Forms.Padding(4);
            this.txtGuestName.Name = "txtGuestName";
            this.txtGuestName.ReadOnly = true;
            this.txtGuestName.Size = new System.Drawing.Size(237, 22);
            this.txtGuestName.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox3.Location = new System.Drawing.Point(557, 256);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(237, 22);
            this.textBox3.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Cornsilk;
            this.textBox4.Location = new System.Drawing.Point(557, 321);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(212, 22);
            this.textBox4.TabIndex = 8;
            // 
            // lblSpace
            // 
            this.lblSpace.AutoSize = true;
            this.lblSpace.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpace.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblSpace.Location = new System.Drawing.Point(805, 321);
            this.lblSpace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSpace.Name = "lblSpace";
            this.lblSpace.Size = new System.Drawing.Size(20, 25);
            this.lblSpace.TabIndex = 9;
            this.lblSpace.Text = "-";
            this.lblSpace.Click += new System.EventHandler(this.lblSpace_Click);
            // 
            // btnDone
            // 
            this.btnDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.Location = new System.Drawing.Point(840, 431);
            this.btnDone.Margin = new System.Windows.Forms.Padding(4);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(125, 28);
            this.btnDone.TabIndex = 10;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // btnEmail
            // 
            this.btnEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmail.Location = new System.Drawing.Point(204, 431);
            this.btnEmail.Margin = new System.Windows.Forms.Padding(4);
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Size = new System.Drawing.Size(115, 28);
            this.btnEmail.TabIndex = 11;
            this.btnEmail.Text = "Email to Guest";
            this.btnEmail.UseVisualStyleBackColor = true;
            this.btnEmail.Click += new System.EventHandler(this.btnEmail_Click);
            // 
            // frmBookingComplete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnEmail);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.lblSpace);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txtGuestName);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblDates);
            this.Controls.Add(this.lblReservationNo);
            this.Controls.Add(this.lblGuestName);
            this.Controls.Add(this.lblBooking);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmBookingComplete";
            this.Text = "BookingComplete";
            this.Load += new System.EventHandler(this.frmBookingComplete_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblBooking;
        private System.Windows.Forms.Label lblGuestName;
        private System.Windows.Forms.Label lblReservationNo;
        private System.Windows.Forms.Label lblDates;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtGuestName;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lblSpace;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Button btnEmail;
    }
}