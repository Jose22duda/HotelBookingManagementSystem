﻿namespace PhumlaKamnandi2024
{
    partial class frmGuestStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGuestStatus));
            this.guestStatusLabel = new System.Windows.Forms.Label();
            this.rbtnNewGuest = new System.Windows.Forms.RadioButton();
            this.backButton = new System.Windows.Forms.Button();
            this.nextButton = new System.Windows.Forms.Button();
            this.rbtnExistingGuest = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guestStatusLabel
            // 
            this.guestStatusLabel.AutoSize = true;
            this.guestStatusLabel.BackColor = System.Drawing.SystemColors.Desktop;
            this.guestStatusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guestStatusLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.guestStatusLabel.Location = new System.Drawing.Point(285, 67);
            this.guestStatusLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.guestStatusLabel.Name = "guestStatusLabel";
            this.guestStatusLabel.Size = new System.Drawing.Size(136, 25);
            this.guestStatusLabel.TabIndex = 0;
            this.guestStatusLabel.Text = "Guest Status";
            // 
            // rbtnNewGuest
            // 
            this.rbtnNewGuest.AutoSize = true;
            this.rbtnNewGuest.BackColor = System.Drawing.SystemColors.Desktop;
            this.rbtnNewGuest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnNewGuest.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.rbtnNewGuest.Location = new System.Drawing.Point(198, 193);
            this.rbtnNewGuest.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnNewGuest.Name = "rbtnNewGuest";
            this.rbtnNewGuest.Size = new System.Drawing.Size(90, 20);
            this.rbtnNewGuest.TabIndex = 1;
            this.rbtnNewGuest.Text = "New Guest";
            this.rbtnNewGuest.UseVisualStyleBackColor = false;
            this.rbtnNewGuest.CheckedChanged += new System.EventHandler(this.rbtnNewGuest_CheckedChanged);
            // 
            // backButton
            // 
            this.backButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.Location = new System.Drawing.Point(65, 351);
            this.backButton.Margin = new System.Windows.Forms.Padding(2);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(87, 25);
            this.backButton.TabIndex = 2;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // nextButton
            // 
            this.nextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextButton.Location = new System.Drawing.Point(516, 351);
            this.nextButton.Margin = new System.Windows.Forms.Padding(2);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(90, 25);
            this.nextButton.TabIndex = 3;
            this.nextButton.Text = "Next";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // rbtnExistingGuest
            // 
            this.rbtnExistingGuest.AutoSize = true;
            this.rbtnExistingGuest.BackColor = System.Drawing.SystemColors.Desktop;
            this.rbtnExistingGuest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnExistingGuest.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.rbtnExistingGuest.Location = new System.Drawing.Point(359, 193);
            this.rbtnExistingGuest.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnExistingGuest.Name = "rbtnExistingGuest";
            this.rbtnExistingGuest.Size = new System.Drawing.Size(109, 20);
            this.rbtnExistingGuest.TabIndex = 4;
            this.rbtnExistingGuest.Text = "Existing Guest";
            this.rbtnExistingGuest.UseVisualStyleBackColor = false;
            this.rbtnExistingGuest.CheckedChanged += new System.EventHandler(this.rbtnExistingGuest_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(11, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(141, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // frmGuestStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(714, 465);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.rbtnExistingGuest);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.rbtnNewGuest);
            this.Controls.Add(this.guestStatusLabel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmGuestStatus";
            this.Text = "GuestStatus";
            this.Load += new System.EventHandler(this.frmGuestStatus_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label guestStatusLabel;
        private System.Windows.Forms.RadioButton rbtnNewGuest;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.RadioButton rbtnExistingGuest;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}