﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhumlaKamnandi2024.Business;
using PhumlaKamnandi2024.Data;


namespace PhumlaKamnandi2024
{
    public partial class frmNewGuest : Form
    {

        public frmNewGuest()
        {
            InitializeComponent();
        }

        #region Form Load Event
        private void frmNewGuest_Load(object sender, EventArgs e)
        {

        }


        #endregion

        #region Button Click Events
        private void btnBack_Click(object sender, EventArgs e)
        {
            frmGuestStatus frmGuestStatus = new frmGuestStatus();
            frmGuestStatus.Show();
            this.Hide();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string email = txtemail.Text;
            string emailPattern = @"^[a-zA-Z][a-zA-Z0-9]*@[a-zA-Z][a-zA-Z0-9]*\.[a-zA-Z]{2,}$";



            if (string.IsNullOrEmpty(txtName.Text) ||
                string.IsNullOrEmpty(txtIDNumber.Text) ||
                string.IsNullOrEmpty(txtphoneNumber.Text) ||
                string.IsNullOrEmpty(txtaddress.Text) ||
                string.IsNullOrEmpty(txtemail.Text)||
                string.IsNullOrEmpty(txtemail.Text))
            {
                MessageBox.Show("Please fill in all details!", "Missing information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!(Regex.IsMatch(email, emailPattern)))
            {
                MessageBox.Show("Invalid email. Please input a valid email","Email Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtemail.Clear();
                txtemail.Focus();
                return;

            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtName.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Invalid name", "Invalid Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtphoneNumber.Text, @"^\d{10}$"))
            {
                MessageBox.Show("Card number must be exactly 16 digits!", "Invalid Card Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtIDNumber.Text, @"^\d{13}$"))
            {
                MessageBox.Show("Card number must be exactly 16 digits!", "Invalid Card Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            else
            {
                if ((txtIDNumber.Text).Length != 13)
                {
                    MessageBox.Show("ID number not valid. Please provide a valid ID number!","Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);

                }
                else if ((txtphoneNumber.Text).Length != 10)
                {
                    MessageBox.Show("Phone number is not valid. Please enter a valid phone number!","Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);

                }
                else
                {
                    GuestController guestController = new GuestController();
                    Guest newGuest = new Guest
                    {
                        GuestID = txtIDNumber.Text.Trim(),
                        Name = txtName.Text.Trim(),
                        ContactNumber = txtphoneNumber.Text.Trim(),
                        Email = txtemail.Text.Trim(),
                        Address = txtaddress.Text.Trim()
                    };

                    try
                    {
                        // Commit the changes to the database
                            MessageBox.Show("New Guest " + txtName.Text+" created.","New Guest",MessageBoxButtons.OK,MessageBoxIcon.Information);
                            frmBookAReservation frmBook = new frmBookAReservation();
                            frmBook.CurrentBooker(newGuest);
                            frmBook.Show();
                            this.Hide();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error creating guest: " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                }

                
            }

        }
        #endregion


    }
}
