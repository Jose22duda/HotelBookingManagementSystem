﻿namespace PhumlaKamnandi2024
{
    partial class frmBookAReservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBookAReservation));
            this.lblBookAReservation = new System.Windows.Forms.Label();
            this.lblNoOfGuests = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmNumberOfGuestsForm2 = new System.Windows.Forms.ComboBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.dateTimeIN = new System.Windows.Forms.DateTimePicker();
            this.dateTimeOUT = new System.Windows.Forms.DateTimePicker();
            this.lblNumberOfChildren = new System.Windows.Forms.Label();
            this.cmbNoOfChildren = new System.Windows.Forms.ComboBox();
            this.lblChildrenNB = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.reserverLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numOfRooms = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBookAReservation
            // 
            this.lblBookAReservation.AutoSize = true;
            this.lblBookAReservation.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblBookAReservation.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookAReservation.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblBookAReservation.Location = new System.Drawing.Point(237, 47);
            this.lblBookAReservation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookAReservation.Name = "lblBookAReservation";
            this.lblBookAReservation.Size = new System.Drawing.Size(202, 25);
            this.lblBookAReservation.TabIndex = 0;
            this.lblBookAReservation.Text = "Book A Reservation\r\n";
            // 
            // lblNoOfGuests
            // 
            this.lblNoOfGuests.AutoSize = true;
            this.lblNoOfGuests.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblNoOfGuests.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfGuests.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblNoOfGuests.Location = new System.Drawing.Point(164, 117);
            this.lblNoOfGuests.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoOfGuests.Name = "lblNoOfGuests";
            this.lblNoOfGuests.Size = new System.Drawing.Size(103, 15);
            this.lblNoOfGuests.TabIndex = 1;
            this.lblNoOfGuests.Text = "Number Of Adults";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Desktop;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label3.Location = new System.Drawing.Point(165, 151);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Day In";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Desktop;
            this.label4.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label4.Location = new System.Drawing.Point(165, 189);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Day Out";
            // 
            // cmNumberOfGuestsForm2
            // 
            this.cmNumberOfGuestsForm2.BackColor = System.Drawing.Color.Cornsilk;
            this.cmNumberOfGuestsForm2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cmNumberOfGuestsForm2.Location = new System.Drawing.Point(328, 117);
            this.cmNumberOfGuestsForm2.Margin = new System.Windows.Forms.Padding(2);
            this.cmNumberOfGuestsForm2.Name = "cmNumberOfGuestsForm2";
            this.cmNumberOfGuestsForm2.Size = new System.Drawing.Size(151, 21);
            this.cmNumberOfGuestsForm2.TabIndex = 14;
            this.cmNumberOfGuestsForm2.SelectedIndexChanged += new System.EventHandler(this.cmNumberOfGuestsForm2_SelectedIndexChanged);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(73, 370);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(91, 23);
            this.btnBack.TabIndex = 9;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(555, 370);
            this.btnCheck.Margin = new System.Windows.Forms.Padding(2);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(91, 23);
            this.btnCheck.TabIndex = 10;
            this.btnCheck.Text = "Check Availability";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // dateTimeIN
            // 
            this.dateTimeIN.Location = new System.Drawing.Point(328, 151);
            this.dateTimeIN.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimeIN.Name = "dateTimeIN";
            this.dateTimeIN.Size = new System.Drawing.Size(151, 20);
            this.dateTimeIN.TabIndex = 12;
            // 
            // dateTimeOUT
            // 
            this.dateTimeOUT.CalendarMonthBackground = System.Drawing.Color.Cornsilk;
            this.dateTimeOUT.Location = new System.Drawing.Point(328, 189);
            this.dateTimeOUT.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimeOUT.Name = "dateTimeOUT";
            this.dateTimeOUT.Size = new System.Drawing.Size(151, 20);
            this.dateTimeOUT.TabIndex = 13;
            // 
            // lblNumberOfChildren
            // 
            this.lblNumberOfChildren.AutoSize = true;
            this.lblNumberOfChildren.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblNumberOfChildren.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblNumberOfChildren.Location = new System.Drawing.Point(164, 236);
            this.lblNumberOfChildren.Name = "lblNumberOfChildren";
            this.lblNumberOfChildren.Size = new System.Drawing.Size(139, 13);
            this.lblNumberOfChildren.TabIndex = 15;
            this.lblNumberOfChildren.Text = "Number of Children (0 - 12) :";
            // 
            // cmbNoOfChildren
            // 
            this.cmbNoOfChildren.BackColor = System.Drawing.Color.Cornsilk;
            this.cmbNoOfChildren.FormattingEnabled = true;
            this.cmbNoOfChildren.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.cmbNoOfChildren.Location = new System.Drawing.Point(328, 228);
            this.cmbNoOfChildren.Name = "cmbNoOfChildren";
            this.cmbNoOfChildren.Size = new System.Drawing.Size(151, 21);
            this.cmbNoOfChildren.TabIndex = 16;
            // 
            // lblChildrenNB
            // 
            this.lblChildrenNB.AutoSize = true;
            this.lblChildrenNB.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblChildrenNB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChildrenNB.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblChildrenNB.Location = new System.Drawing.Point(326, 263);
            this.lblChildrenNB.Name = "lblChildrenNB";
            this.lblChildrenNB.Size = new System.Drawing.Size(303, 13);
            this.lblChildrenNB.TabIndex = 17;
            this.lblChildrenNB.Text = "NB : YOU CAN ONLY CHOOSE UP TO 3 CHILDREN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(250, 59);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 19;
            // 
            // reserverLabel
            // 
            this.reserverLabel.AutoSize = true;
            this.reserverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reserverLabel.Location = new System.Drawing.Point(164, 69);
            this.reserverLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.reserverLabel.Name = "reserverLabel";
            this.reserverLabel.Size = new System.Drawing.Size(0, 17);
            this.reserverLabel.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Desktop;
            this.label5.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label5.Location = new System.Drawing.Point(164, 306);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Number of Rooms :";
            // 
            // numOfRooms
            // 
            this.numOfRooms.BackColor = System.Drawing.Color.Cornsilk;
            this.numOfRooms.FormattingEnabled = true;
            this.numOfRooms.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.numOfRooms.Location = new System.Drawing.Point(329, 298);
            this.numOfRooms.Name = "numOfRooms";
            this.numOfRooms.Size = new System.Drawing.Size(151, 21);
            this.numOfRooms.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_04_40_10;
            this.pictureBox1.Location = new System.Drawing.Point(11, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(111, 101);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // frmBookAReservation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(749, 448);
            this.Controls.Add(this.numOfRooms);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.reserverLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblChildrenNB);
            this.Controls.Add(this.cmbNoOfChildren);
            this.Controls.Add(this.lblNumberOfChildren);
            this.Controls.Add(this.dateTimeOUT);
            this.Controls.Add(this.dateTimeIN);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.cmNumberOfGuestsForm2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblNoOfGuests);
            this.Controls.Add(this.lblBookAReservation);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmBookAReservation";
            this.Text = "BookAReservation";
            this.Load += new System.EventHandler(this.frmBookAReservation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookAReservation;
        private System.Windows.Forms.Label lblNoOfGuests;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmNumberOfGuestsForm2;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker dateTimeIN;
        private System.Windows.Forms.DateTimePicker dateTimeOUT;
        private System.Windows.Forms.Label lblNumberOfChildren;
        private System.Windows.Forms.ComboBox cmbNoOfChildren;
        private System.Windows.Forms.Label lblChildrenNB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label reserverLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox numOfRooms;
    }
}