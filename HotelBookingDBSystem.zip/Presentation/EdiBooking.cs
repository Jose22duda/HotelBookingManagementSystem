﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhumlaKamnandi2024.Business;

namespace PhumlaKamnandi2024
{
    public partial class frmEditBooking : Form
    {
        Booking booking;
        public frmEditBooking()
        {
            InitializeComponent();
        }

        #region Form Load Event
        private void frmEditBooking_Load(object sender, EventArgs e)
        {

        }

        #endregion

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmMain frmMain = new frmMain();
            frmMain.Show();
            this.Close();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtReferenceNo.Text))
            {
                MessageBox.Show("Please provide a valid Booking Reference Number!", "Note", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                BookingController controller = new BookingController();
               
                bool contained = false;
                foreach (Booking book in controller.AllBookings)
                {
                    if (book.BookingID == txtReferenceNo.Text)
                    {
                        contained = true;
                        this.booking = book;
                        break;
                    }
                }
                if (contained)
                {
                    MessageBox.Show("Booking Found", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    frmBookingOptions frmOptions = new frmBookingOptions();
                    frmOptions.CurrentBooking( booking);
                    frmOptions.Show();
                    this.Close();

                }
                else
                {
                    MessageBox.Show("No booking found!","Error",MessageBoxButtons.RetryCancel,MessageBoxIcon.Error);
                    frmMain frmMain = new frmMain();
                    frmMain.Show();
                    this.Close();


                }

            }
        }
    }
}
