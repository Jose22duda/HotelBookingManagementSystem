﻿namespace PhumlaKamnandi2024
{
    partial class frmCancelBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCancelBooking = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonYes = new System.Windows.Forms.Button();
            this.buttonNO = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCancelBooking
            // 
            this.lblCancelBooking.AutoSize = true;
            this.lblCancelBooking.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblCancelBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCancelBooking.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblCancelBooking.Location = new System.Drawing.Point(389, 59);
            this.lblCancelBooking.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCancelBooking.Name = "lblCancelBooking";
            this.lblCancelBooking.Size = new System.Drawing.Size(228, 32);
            this.lblCancelBooking.TabIndex = 1;
            this.lblCancelBooking.Text = "Cancel Booking";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.pictureBox1.Location = new System.Drawing.Point(13, 30);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 151);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // buttonYes
            // 
            this.buttonYes.BackColor = System.Drawing.SystemColors.Desktop;
            this.buttonYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonYes.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonYes.Location = new System.Drawing.Point(664, 279);
            this.buttonYes.Name = "buttonYes";
            this.buttonYes.Size = new System.Drawing.Size(168, 59);
            this.buttonYes.TabIndex = 2;
            this.buttonYes.Text = "YES";
            this.buttonYes.UseVisualStyleBackColor = false;
            this.buttonYes.Click += new System.EventHandler(this.buttonYes_Click);
            // 
            // buttonNO
            // 
            this.buttonNO.BackColor = System.Drawing.SystemColors.Desktop;
            this.buttonNO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNO.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonNO.Location = new System.Drawing.Point(228, 280);
            this.buttonNO.Name = "buttonNO";
            this.buttonNO.Size = new System.Drawing.Size(163, 59);
            this.buttonNO.TabIndex = 3;
            this.buttonNO.Text = "NO";
            this.buttonNO.UseVisualStyleBackColor = false;
            this.buttonNO.Click += new System.EventHandler(this.buttonNO_Click);
            // 
            // frmCancelBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.sl_030220_28570_03;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(960, 479);
            this.Controls.Add(this.buttonNO);
            this.Controls.Add(this.buttonYes);
            this.Controls.Add(this.lblCancelBooking);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmCancelBooking";
            this.Text = "CancelBooking";
            this.Load += new System.EventHandler(this.frmCancelBooking_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblCancelBooking;
        private System.Windows.Forms.Button buttonYes;
        private System.Windows.Forms.Button buttonNO;
    }
}