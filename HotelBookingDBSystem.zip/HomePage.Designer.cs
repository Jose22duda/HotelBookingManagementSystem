﻿namespace PhumlaKamnandi2024
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbookReservation = new System.Windows.Forms.Button();
            this.btneditBooking = new System.Windows.Forms.Button();
            this.lblStaffportal = new System.Windows.Forms.Label();
            this.btnPromotions = new System.Windows.Forms.Button();
            this.btnamenities = new System.Windows.Forms.Button();
            this.btnmore = new System.Windows.Forms.Button();
            this.lblhomeLabel = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnbookReservation
            // 
            this.btnbookReservation.BackColor = System.Drawing.SystemColors.Control;
            this.btnbookReservation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbookReservation.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnbookReservation.Location = new System.Drawing.Point(8, 179);
            this.btnbookReservation.Margin = new System.Windows.Forms.Padding(2);
            this.btnbookReservation.Name = "btnbookReservation";
            this.btnbookReservation.Size = new System.Drawing.Size(139, 25);
            this.btnbookReservation.TabIndex = 0;
            this.btnbookReservation.Text = "Book Reservation";
            this.btnbookReservation.UseVisualStyleBackColor = false;
            this.btnbookReservation.Click += new System.EventHandler(this.btnbookReservation_Click);
            // 
            // btneditBooking
            // 
            this.btneditBooking.BackColor = System.Drawing.SystemColors.Control;
            this.btneditBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneditBooking.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btneditBooking.Location = new System.Drawing.Point(8, 233);
            this.btneditBooking.Margin = new System.Windows.Forms.Padding(2);
            this.btneditBooking.Name = "btneditBooking";
            this.btneditBooking.Size = new System.Drawing.Size(139, 25);
            this.btneditBooking.TabIndex = 1;
            this.btneditBooking.Text = "Edit Booking";
            this.btneditBooking.UseVisualStyleBackColor = false;
            this.btneditBooking.Click += new System.EventHandler(this.btneditBooking_Click);
            // 
            // lblStaffportal
            // 
            this.lblStaffportal.AutoSize = true;
            this.lblStaffportal.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblStaffportal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStaffportal.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblStaffportal.Location = new System.Drawing.Point(11, 88);
            this.lblStaffportal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStaffportal.Name = "lblStaffportal";
            this.lblStaffportal.Size = new System.Drawing.Size(120, 26);
            this.lblStaffportal.TabIndex = 11;
            this.lblStaffportal.Text = "Staff Portal";
            // 
            // btnPromotions
            // 
            this.btnPromotions.BackColor = System.Drawing.SystemColors.Control;
            this.btnPromotions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPromotions.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnPromotions.Location = new System.Drawing.Point(62, 516);
            this.btnPromotions.Margin = new System.Windows.Forms.Padding(2);
            this.btnPromotions.Name = "btnPromotions";
            this.btnPromotions.Size = new System.Drawing.Size(93, 23);
            this.btnPromotions.TabIndex = 12;
            this.btnPromotions.Text = "Promotions";
            this.btnPromotions.UseVisualStyleBackColor = false;
            // 
            // btnamenities
            // 
            this.btnamenities.BackColor = System.Drawing.SystemColors.Control;
            this.btnamenities.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnamenities.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnamenities.Location = new System.Drawing.Point(380, 516);
            this.btnamenities.Margin = new System.Windows.Forms.Padding(2);
            this.btnamenities.Name = "btnamenities";
            this.btnamenities.Size = new System.Drawing.Size(85, 23);
            this.btnamenities.TabIndex = 14;
            this.btnamenities.Text = "Amenities";
            this.btnamenities.UseVisualStyleBackColor = false;
            this.btnamenities.Click += new System.EventHandler(this.btnamenities_Click);
            // 
            // btnmore
            // 
            this.btnmore.BackColor = System.Drawing.SystemColors.Control;
            this.btnmore.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmore.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnmore.Location = new System.Drawing.Point(738, 516);
            this.btnmore.Margin = new System.Windows.Forms.Padding(2);
            this.btnmore.Name = "btnmore";
            this.btnmore.Size = new System.Drawing.Size(85, 23);
            this.btnmore.TabIndex = 15;
            this.btnmore.Text = "More";
            this.btnmore.UseVisualStyleBackColor = false;
            // 
            // lblhomeLabel
            // 
            this.lblhomeLabel.AutoSize = true;
            this.lblhomeLabel.BackColor = System.Drawing.SystemColors.Desktop;
            this.lblhomeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhomeLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblhomeLabel.Location = new System.Drawing.Point(11, 29);
            this.lblhomeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblhomeLabel.Name = "lblhomeLabel";
            this.lblhomeLabel.Size = new System.Drawing.Size(310, 25);
            this.lblhomeLabel.TabIndex = 19;
            this.lblhomeLabel.Text = "Welcome to the Home Page!\r\n";
            // 
            // btnGenerate
            // 
            this.btnGenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.Location = new System.Drawing.Point(8, 285);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(139, 23);
            this.btnGenerate.TabIndex = 20;
            this.btnGenerate.Text = "Generate Report";
            this.btnGenerate.UseVisualStyleBackColor = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PhumlaKamnandi2024.Properties.Resources.WhatsApp_Image_2024_10_03_at_09_38_54;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(852, 620);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.lblhomeLabel);
            this.Controls.Add(this.btnmore);
            this.Controls.Add(this.btnamenities);
            this.Controls.Add(this.btnPromotions);
            this.Controls.Add(this.lblStaffportal);
            this.Controls.Add(this.btneditBooking);
            this.Controls.Add(this.btnbookReservation);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbookReservation;
        private System.Windows.Forms.Button btneditBooking;
        private System.Windows.Forms.Label lblStaffportal;
        private System.Windows.Forms.Button btnPromotions;
        private System.Windows.Forms.Button btnamenities;
        private System.Windows.Forms.Button btnmore;
        private System.Windows.Forms.Label lblhomeLabel;
        private System.Windows.Forms.Button btnGenerate;
    }
}

