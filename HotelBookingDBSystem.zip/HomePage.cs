﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhumlaKamnandi2024.Business;
using System.Windows.Forms;
using PhumlaKamnandi2024.Presentation;

namespace PhumlaKamnandi2024
{
    public partial class frmMain : Form
    {
        private Collection<Guest> guests;
        private GuestController guestController;
        public frmMain()
        {
            InitializeComponent();
        }



        #region Form Load Event
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        #endregion


        private void btnbookReservation_Click(object sender, EventArgs e)
        {
            frmGuestStatus frmMain =new frmGuestStatus();
            frmMain.Show();
            this.Hide(); // Hides the main form when the Book a reservation form is open.
        }

        private void btneditBooking_Click(object sender, EventArgs e)
        {
            frmEditBooking frmEditBooking = new frmEditBooking();
            frmEditBooking.Show();
            this.Hide();
        }

        private void btnamenities_Click(object sender, EventArgs e)
        {
            frmAmenities frmAmenities = new frmAmenities();
            frmAmenities.Show();
            this.Hide();
        }
    }
}
