﻿using System;
using System.Collections.ObjectModel;
using PhumlaKamnandi2024.Data;

namespace PhumlaKamnandi2024.Business
{
    internal class GuestController
    {
        #region Data Members
        private GuestDB guestDB;
        private Collection<Guest> guests;
        #endregion

        #region Constructor
        public GuestController()
        {
            // Instantiate the GuestDB object
            guestDB = new GuestDB();

            // Initialize the guest collection
            guests = new Collection<Guest>();
            foreach (var guest in guestDB.AllGuests)
            {
                guests.Add(guest);
            }
        }
        #endregion

        #region Database Communication
        public void DataMaintenance(Guest aGuest, PhumlaKamnandiDB.DBOperation operation)
        {
            // Call DataSetChange method
            guestDB.DataSetChange(aGuest, operation);

            switch (operation)
            {
                case PhumlaKamnandiDB.DBOperation.Add:
                    guests.Add(aGuest);
                    break;

                case PhumlaKamnandiDB.DBOperation.Edit:
                    int index = FindIndex(aGuest);
                    if (index != -1) // Ensure the guest was found
                    {
                        guests[index] = aGuest; // Update the guest in the collection
                    }
                    break;

                case PhumlaKamnandiDB.DBOperation.Delete:
                    int deleteIndex = FindIndex(aGuest);
                    if (deleteIndex != -1) // Ensure the guest was found
                    {
                        guests.RemoveAt(deleteIndex); // Remove the guest from the collection
                    }
                    break;
            }
        }
        #endregion

        #region Search Methods
        public Guest Find(string ID)
        {
            foreach (var guest in guests)
            {
                if (guest.GuestID == ID)
                {
                    return guest; // Return the guest if found
                }
            }
            return null; // Return null if not found
        }

        public int FindIndex(Guest guest)
        {
            for (int counter = 0; counter < guests.Count; counter++)
            {
                if (guest.GuestID == guests[counter].GuestID)
                {
                    return counter; // Return index if found
                }
            }
            return -1; // Return -1 if not found
        }
        public bool FinalizeChanges(Guest guest)
        {
            return guestDB.UpdateDataSource(guest);
        }


        public Collection<Guest> AllGuests
        {
            get { return guestDB.AllGuests; }
        }

        #endregion
    }
}
