﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



using System;

namespace PhumlaKamnandi2024.Business
{
    public class Booking
    {
        #region Data Members
        private string bookingId;
        private string guestId;
        private string checkInDate;
        private string checkOutDate;
        private string numberOfRooms;
        private string totalCost; // Keep as string
        private string aDeposit;//added this
        private string paymentStatus;

        #endregion

        #region Properties

        public string BookingID
        {
            get { return bookingId; }
            set { bookingId = value; }
        }

        public string GuestID
        {
            get { return guestId; }
            set { guestId = value; }
        }

        public string CheckInDate
        {
            get { return checkInDate; }
            set { checkInDate = value; }
        }

        public string CheckOutDate
        {
            get { return checkOutDate; }
            set { checkOutDate = value; }
        }

        public string NumberOfRooms
        {
            get { return numberOfRooms; }
            set { numberOfRooms = value; }
        }

        public string TotalAmount
        {
            get { return totalCost; }
            set { totalCost = value; }
        }

        public string PaymentStatus
        {
            get { return paymentStatus; }
            set { paymentStatus = value; }
        }

        public string Deposit//added this
        {
            get { return aDeposit; }
            set { aDeposit = value; }
        }
                

        #endregion

        #region Constructors
        public Booking()
        {
            bookingId = "";
            guestId = "";
            checkInDate = "";
            checkOutDate = "";
            numberOfRooms = "";
            totalCost = "";
            paymentStatus = "";
            aDeposit = ""; //added
        }

        public Booking( string bookingId, string guestId, string numberOfRooms, string checkInDate, string checkOutDate, string totalCost, string paymentStatus, string aDeposit )//added this
        {
            this.bookingId = bookingId;
            this.guestId = guestId;
            this.checkInDate = checkInDate;
            this.checkOutDate = checkOutDate;
            this.numberOfRooms = numberOfRooms;
            this.totalCost = totalCost;
            this.paymentStatus = paymentStatus;
            this.aDeposit = aDeposit;//added this
        }
        #endregion

        #region ToString Method
        public override string ToString()
        {
            return 
                   $"Booking ID: {bookingId}\n" +
                   $"Guest ID: {guestId}\n" +
                   $"Check-in Date: {checkInDate}\n" +
                   $"Check-out Date: {checkOutDate}\n" +
                   $"Number of Rooms: {numberOfRooms}\n" +
                   $"Total Cost: R{totalCost}\n" +
                   $"Payment Status: {paymentStatus}\n" +
                   $"Deposit: {aDeposit}";//added this



        }
        #endregion
    }
}
