﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandi2024.Business
{
    public class Guest
    {
        // Attributes for Guest
        private string guestid;
        private string name;
        private string contactnumber;
        private string email;
        private string address;

        #region Properties


        public string GuestID
        {
            get { return guestid; }
            set { guestid = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string ContactNumber
        {
            get { return contactnumber; }
            set { contactnumber = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        #endregion

        #region Constructors
        public Guest()
        {

            guestid = "";
            name = "";
            contactnumber = "";
            email = "";
            address = "";
        }

        public Guest( string guestid,string name, string phone, string email, string address)
        {
            
            this.guestid = guestid;
            this.name = name;
            this.contactnumber = phone;
            this.email = email;
            this.address = address;
        }
        #endregion

        #region ToStringMethod
        public override string ToString()
        {
            return $"GuestID: {guestid}\nName: {name}\nPhone: {contactnumber}\nEmail: {email}\nAddress: {address}";
        }
        #endregion
    }
}