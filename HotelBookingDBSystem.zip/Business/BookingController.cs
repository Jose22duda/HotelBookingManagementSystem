﻿using System;
using System.Collections.ObjectModel;
using PhumlaKamnandi2024.Data;

namespace PhumlaKamnandi2024.Business
{
    internal class BookingController
    {
        #region Data Members
        private BookingDB bookingDB;
        private Collection<Booking> bookings;
        #endregion

        #region Constructor
        public BookingController()
        {
            // Instantiate the BookingDB object to communicate with the database
            bookingDB = new BookingDB();
            bookings = bookingDB.AllBookings;
        }
        #endregion

        #region Database Communication
        public void DataMaintenance(Booking aBooking, PhumlaKamnandiDB.DBOperation operation)
        {
            // Call DataSetChange method
            bookingDB.DataSetChange(aBooking, operation);

            switch (operation)
            {
                case PhumlaKamnandiDB.DBOperation.Add:
                    bookings.Add(aBooking);
                    break;

                case PhumlaKamnandiDB.DBOperation.Edit:
                    int index = FindIndex(aBooking);
                    if (index != -1) // Ensure the booking was found
                    {
                        bookings[index] = aBooking; // Update the booking in the collection
                    }
                    break;

                case PhumlaKamnandiDB.DBOperation.Delete:
                    int deleteIndex = FindIndex(aBooking);
                    if (deleteIndex != -1) // Ensure the booking was found
                    {
                        bookings.RemoveAt(deleteIndex); // Remove the booking from the collection
                    }
                    break;
            }
        }
        #endregion

        #region Search Methods
        public Booking Find(string ID)
        {
            foreach (var booking in bookings)
            {
                if (booking.BookingID == ID)
                {
                    return booking; // Return the booking if found
                }
            }
            return null; // Return null if not found
        }

        public int FindIndex(Booking aBooking)
        {
            for (int counter = 0; counter < bookings.Count; counter++)
            {
                if (aBooking.BookingID == bookings[counter].BookingID)
                {
                    return counter; // Return index if found
                }
            }
            return -1; // Return -1 if not found
        }
        public bool FinalizeChanges(Booking booking, PhumlaKamnandiDB.DBOperation operation)
        {        
            switch (operation)
            {
                case PhumlaKamnandiDB.DBOperation.Add:
                    return bookingDB.InsertDataSource(booking);

                case PhumlaKamnandiDB.DBOperation.Edit:
                    return bookingDB.UpdateDataSource(booking);
                case PhumlaKamnandiDB.DBOperation.Delete:
                    return bookingDB.DeleteDataSource(booking);

            }
            return false;

        }

        public Collection<Booking> AllBookings
        {
            get { return bookingDB.AllBookings; }
        }
        #endregion
    }
}
